/**
 * Clase que representa un robot en el sistema
 * Los robots pueden moverse y retornar a su posición inicial
 */
public class Robot {
    // Atributos de posición y estado
    private String nombre;
    private int posX;           // Posición actual X
    private int posY;           // Posición actual Y
    private int posInicialX;    // Posición inicial X (para retornar)
    private int posInicialY;
    private Triangle forma;// Posición inicial Y (para retornar)
    private boolean activo;     // Estado del robot
    
    /**
     * Constructor de Robot
     * @param nombre - Nombre identificador del robot
     * @param posX - Posición inicial X
     * @param posY - Posición inicial Y
     */
    public Robot(String nombre, int posX, int posY) {
        this.nombre = nombre;
        this.posX = posX;
        this.posY = posY;
        this.posInicialX = posX;  // Guardar posición inicial
        this.posInicialY = posY;
        this.forma=new Triangle();
        this.activo = true;       // Robot activo por defecto
    }
    
    /**
     * MÉTODO: Mover el robot a una nueva posición
     * @param nuevaX - Nueva coordenada X
     * @param nuevaY - Nueva coordenada Y
     */
    public void mover(int nuevaX, int nuevaY) {
        this.posX = nuevaX;
        this.posY = nuevaY;
        System.out.println("Robot '" + nombre + "' movido a posición (" + nuevaX + ", " + nuevaY + ")");
    }
    
    /**
     * MÉTODO: Retornar el robot a su posición inicial
     * Usa las coordenadas guardadas al crear el robot
     */
    public void retornarAPosicionInicial() {
        this.posX = posInicialX;
        this.posY = posInicialY;
        System.out.println("Robot '" + nombre + "' retornó a posición inicial (" + posInicialX + ", " + posInicialY + ")");
    }
    
    /**
     * MÉTODO: Obtener la distancia actual desde la posición inicial
     * @return Distancia euclidiana desde la posición inicial
     */
    public double getDistanciaDesdeInicio() {
        int deltaX = posX - posInicialX;
        int deltaY = posY - posInicialY;
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }
    public String getNombre() { return nombre; }
    public int getPosX() { return posX; }
    public int getPosY() { return posY; }
    public int getPosInicialX() { return posInicialX; }
    public int getPosInicialY() { return posInicialY; }
    public boolean isActivo() { return activo; }
    
    public void setActivo(boolean activo) { this.activo = activo; }
    
    /**
     * MÉTODO: Mostrar información del robot
     * @return String con información completa del robot
     */
    public String getInfo() {
        return "Robot: " + nombre + 
               " | Posición: (" + posX + ", " + posY + ")" +
               " | Inicial: (" + posInicialX + ", " + posInicialY + ")" +
               " | Activo: " + activo;
    }
}