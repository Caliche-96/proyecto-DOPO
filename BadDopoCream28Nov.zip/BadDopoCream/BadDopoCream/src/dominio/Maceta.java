package dominio;
 /**
  * Subclase 2: Maceta [cite: 50]
  * @author Carlos Duban Rojas & Eduardo Rico
  * @version 1.0
  */
// Subclase 2: Maceta [cite: 50]
public class Maceta extends Enemy {
    @Override
    public void move() {
        // Lógica: persigue al jugador, no puede romper bloques [cite: 50]
    }
}