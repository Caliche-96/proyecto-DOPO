package dominio;
 /**
  * Subclase 3: CalamarNaranja [cite: 51, 52]
  * @author Carlos Duban Rojas & Eduardo Rico
  * @version 1.0
  */
// Subclase 3: CalamarNaranja [cite: 51, 52]
public class Calamar extends Enemy {
    @Override
    public void move() {
        // Lógica: persigue al jugador y se detiene para destruir un bloque de hielo a la vez [cite: 51, 52]
    }
}