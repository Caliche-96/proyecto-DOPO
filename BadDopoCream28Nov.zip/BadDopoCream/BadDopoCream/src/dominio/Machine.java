package dominio;

public class Machine {
    // Aca se colo
}
