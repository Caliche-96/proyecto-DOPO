package dominio;

public class Platano extends Fruit {
    private int posX;
    private int posY;

    /**
     * Constructor del Platano
     */
    public Platano() {
        super("Platano", 100); 

    }

    /**
     * Retorna la posicion X del Platano
     * @return
     */
    public int getPosX() {
        return posX;
    }   
    /**
     * Retorna la posicion Y del Platano
     * @return
     */
    public int getPosY() {
        return posY;
    }
}
