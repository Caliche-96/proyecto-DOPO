package dominio;

public class IceBlock {

}
