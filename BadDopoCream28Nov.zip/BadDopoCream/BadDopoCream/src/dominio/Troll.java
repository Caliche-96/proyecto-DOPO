package dominio;
 /**
  * Subclase 1: Trolls [cite: 48, 49]
  * @author Carlos Duban Rojas & Eduardo Rico
  * @version 1.0
  */
// Subclase 1: Trolls [cite: 48, 49]
public class Troll extends Enemy {
    @Override
    public void move() {
        // Lógica: se desplaza en líneas rectas y cambia de dirección al chocar con obstáculo/borde [cite: 48]
    }
}