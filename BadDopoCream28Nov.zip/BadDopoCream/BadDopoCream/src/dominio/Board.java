package dominio;

import java.util.ArrayList;

public class Board {
    private Player player;
    // Otros atributos como enemigos, bloques de hielo, etc.
    private List<Enemy> enemies;
    private List<IceBlock> iceBlocks;
    private int width;
    private int height;
    public Board(int width, int height, Player player) {
        this.width = width;
        this.height = height;
        this.player = player;
        this.enemies = new ArrayList<>();
        this.iceBlocks = new ArrayList<>();
    }

    public void addEnemy(Enemy enemy) {
        enemies.add(enemy);
    }

    public void addIceBlock(IceBlock iceBlock) {
        iceBlocks.add(iceBlock);
    }

    // Métodos para actualizar el estado del tablero, mover actores, manejar colisiones, etc.
    public void update() {
        player.move();
        for (Enemy enemy : enemies) {
            enemy.move();
        }
        // Lógica adicional para manejar interacciones y colisiones
        
    }


}
