package dominio;
 /**
  * Subclase 4: Narval [cite: 53, 54]
  * @author Carlos Duban Rojas & Eduardo Rico
  * @version 1.0
  */
 // Subclase 4: Narval [cite: 53, 54]
public class Narval extends Enemy {
    @Override
    public void move() {
        // Lógica: recorrido aleatorio, pero embiste rápido si un helado se alinea vertical/horizontalmente [cite: 53, 54]
    }
}