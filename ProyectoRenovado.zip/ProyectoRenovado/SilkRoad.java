import java.util.ArrayList;
import java.util.Scanner;
/**
 * Esta va a ser la clase principal del proyecto, desde la cual se va a manejar todo
 * Se hará creador de la ruta de seda y el control de días y movimientos por parte del usuario
 * 
 * @author Carlos Duban Rojas Riveros y Diego Alejandro Mesa Alonso
 * @version 2.0 29/09/2025
 */


public class SilkRoad {
    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;

    public SilkRoad(int length) {
        this.length = length;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
    }

    public void addStore(Store s) {
        stores.add(s);
    }

    public void addRobot(Robot robot) {
        robots.add(robot);
    }

    public void showRoute() {
        System.out.println("Ruta de Seda de longitud " + length);
        for(Store st : stores){
            System.out.println("Tienda en posición " + st.getLocation() + " con " + st.getCoins() + " monedas.");
        }
        for(Robot r : robots){
            System.out.println("Robot en posición " + r.getLocation() + " con " + r.getCoins() + " monedas recogidas.");
        }
    }

    // Aquí está el método principal
    public static void main(String[] args) {
        // Crear una ruta de seda de 10 posiciones
        SilkRoad road = new SilkRoad(10);

        // Crear tiendas
        Store s1 = new Store(2, 5);
        Store s2 = new Store(7, 10);

        // Crear un robot
        Robot r1 = new Robot(0);

        // Agregar objetos a la ruta
        road.addStore(s1);
        road.addStore(s2);
        road.addRobot(r1);

        // Mostrar estado inicial
        road.showRoute();

        // Simular movimiento y recolección
        r1.moveTo(2);
        s1.giveCoins(r1);

        // Mostrar estado después de la recolección
        System.out.println("\nDespués de que el robot recogió en la tienda 1:");
        road.showRoute();
    }
}
