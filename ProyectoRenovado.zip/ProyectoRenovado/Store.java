import java.awt.*;

public class Store {
    private int location;
    private int coins;

    public Store(int location, int coins) {
        this.location = location;
        this.coins = coins;
    }

    public int getLocation() {
        return location;
    }

    public int getCoins() {
        return coins;
    }

    public void giveCoins(Robot robot) {
        robot.collect(coins);
        this.coins = 0;
    }
}
