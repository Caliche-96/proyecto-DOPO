public class Robot {
    private int location;
    private int coins;
    private Rectangle form;
    
    public Robot(int start) {
        this.location = start;
        this.coins = 0;
    }

    public void moveTo(int newLocation) {
        this.location = newLocation;
    }

    public void collect(int c) {
        coins += c;
    }

    public int getCoins() {
        return coins;
    }

    public int getLocation() {
        return location;
    }
}
