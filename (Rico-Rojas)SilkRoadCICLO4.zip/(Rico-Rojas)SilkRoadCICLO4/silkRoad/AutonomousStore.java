package silkRoad;

import java.util.Random;

/**
 * Tienda autónoma que escoge su propia posición al ser creada.
 */
public class AutonomousStore extends Store {

    /**
     * Crea una tienda autónoma que elige aleatoriamente su ubicación en el tablero.
     *
     * @param tenges cantidad inicial de tenges
     * @param cellSize tamaño de cada celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color de la tienda
     * @param boardSize tamaño del tablero (número de celdas por lado)
     */
    public AutonomousStore(int xCell, int yCell, int tenges,
                           int cellSize, int offsetX, int offsetY, String color) {
        super(xCell, yCell, tenges, cellSize, offsetX, offsetY, color);
    }
}
