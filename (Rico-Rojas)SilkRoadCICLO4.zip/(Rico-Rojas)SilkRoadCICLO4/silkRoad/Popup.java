package silkRoad;
import javax.swing.JOptionPane;

/**
 * Utilidad simple para mostrar mensajes al usuario mediante ventanas emergentes.
 */
public class Popup {

    /**
     * Muestra un mensaje informativo al usuario.
     *
     * @param message Texto a mostrar.
     */
    public static void show(String message) {
        try {
            JOptionPane.showMessageDialog(null, message, "SilkRoad", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            System.out.println(message);
        }
    }

}
