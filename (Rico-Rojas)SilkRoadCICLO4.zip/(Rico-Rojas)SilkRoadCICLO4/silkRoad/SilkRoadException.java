package silkRoad;

/**
 * Clase que define todas las excepciones utilizadas en el proyecto SilkRoad.
 * Contiene mensajes de error comunes que pueden lanzarse en distintas operaciones
 * del sistema (colocación, eliminación, validación, etc.).
 *
 * 
 */
public class SilkRoadException extends Exception {

    // Errores generales
    public static final String INVALID_CELL = "Casilla inválida o inexistente.";
    public static final String CELL_OCCUPIED = "La casilla ya está ocupada.";
    public static final String NO_ROBOT_FOUND = "No se encontró ningún robot en la casilla.";
    public static final String NO_STORE_FOUND = "No se encontró ninguna tienda en la casilla.";

    // Errores de tipo o parámetros
    public static final String INVALID_ROBOT_TYPE = "Tipo de robot no válido.";
    public static final String INVALID_STORE_TYPE = "Tipo de tienda no válido.";

    // Constructor
    public SilkRoadException(String message) {
        super(message);
    }
}
