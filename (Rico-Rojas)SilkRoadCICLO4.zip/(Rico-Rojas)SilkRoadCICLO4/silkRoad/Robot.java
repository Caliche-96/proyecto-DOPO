package silkRoad;
import java.util.ArrayList;
import java.util.List;
import Shapes.*;

/**
 * Clase que representa un robot en el tablero de SilkRoad.
 * El robot posee una forma (círculo) usada para su representación gráfica.
 * Ya no extiende de Circle, sino que la usa como atributo (composición).
 */
public class Robot {
    private Circle circle;
    private int xCell;
    private int yCell;
    private int startX;
    private int startY;
    private int spiralIndex;
    private int startIndex;
    private int cellSize;
    private int offsetX;
    private int offsetY;
    private String color;
    private int totalProfit;
    private int lastProfit;
    private List<Integer> profitHistory;

    /**
     * Crea un nuevo robot en una celda específica.
     *
     * @param xCell posición X de la celda
     * @param yCell posición Y de la celda
     * @param startIndex índice inicial en el camino espiral
     * @param cellSize tamaño de cada celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color del robot
     */
    public Robot(int xCell, int yCell, int startIndex, int cellSize, int offsetX, int offsetY, String color) {
        this.circle = new Circle();
        this.xCell = xCell;
        this.yCell = yCell;
        this.startX = xCell;
        this.startY = yCell;
        this.spiralIndex = startIndex;
        this.startIndex = startIndex;
        this.cellSize = cellSize;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.color = color;
        this.totalProfit = 0;
        this.lastProfit = 0;
        this.profitHistory = new ArrayList<>();

        int size = cellSize - 5;
        int margin = (cellSize - size) / 2;
        circle.changeSize(size);
        circle.changeColor(color);
        circle.moveHorizontal(offsetX + xCell * cellSize + margin + 50);
        circle.moveVertical(offsetY + yCell * cellSize + margin);
        circle.makeVisible();
    }

    /**
     * Mueve el robot paso a paso a lo largo del camino espiral.
     *
     * @param targetIndex índice de destino en la ruta espiral
     * @param spiralPath arreglo con coordenadas [x,y] de la ruta espiral
     */
    public void moveAlongSpiral(int targetIndex, int[][] spiralPath) {
        if (targetIndex < 0 || targetIndex >= spiralPath.length) return;

        int step = (targetIndex > spiralIndex) ? 1 : -1;
        while (spiralIndex != targetIndex) {
            spiralIndex += step;
            int newX = spiralPath[spiralIndex][0];
            int newY = spiralPath[spiralIndex][1];
            int dx = (newX - xCell) * cellSize;
            int dy = (newY - yCell) * cellSize;
            circle.moveHorizontal(dx);
            circle.moveVertical(dy);
            xCell = newX;
            yCell = newY;
            Canvas.getCanvas().wait(200);
        }
    }

    /**
     * Añade una ganancia al robot y la registra en su historial.
     *
     * @param profit cantidad ganada en este movimiento
     */
    public void addProfit(int profit) {
        this.totalProfit += profit;
        this.lastProfit = profit;
        this.profitHistory.add(profit);
    }

    /**
     * Hace que el robot parpadee (para indicar que fue el de mayor ganancia).
     *
     * @param times número de parpadeos
     */
    public void blink(int times) {
        for (int i = 0; i < times; i++) {
            circle.makeInvisible();
            Canvas.getCanvas().wait(250);
            circle.makeVisible();
            Canvas.getCanvas().wait(250);
        }
    }

    /**
     * Restaura el robot a su posición inicial.
     */
    public void reset() {
        int dx = (startX - xCell) * cellSize;
        int dy = (startY - yCell) * cellSize;
        circle.moveHorizontal(dx);
        circle.moveVertical(dy);
        xCell = startX;
        yCell = startY;
        spiralIndex = startIndex;
    }
    
    public void makeVisible() {
        circle.makeVisible();
    }
    
    /**
     * Hace invisible la representación gráfica del robot.
     */
    public void makeInvisible() {
        circle.makeInvisible();
    }

    // ---------- Getters ----------

    /**
     * @return color del robot
     */
    public String getColor() { return color; }

    /**
     * @return posición X actual
     */
    public int getXCell() { return xCell; }

    /**
     * @return posición Y actual
     */
    public int getYCell() { return yCell; }

    /**
     * @return índice actual en la ruta espiral
     */
    public int getSpiralIndex() { return spiralIndex; }

    /**
     * @return ganancia total del robot
     */
    public int getTotalProfit() { return totalProfit; }

    /**
     * @return ganancia del último movimiento
     */
    public int getLastProfit() { return lastProfit; }

    /**
     * @return historial de ganancias
     */
    public List<Integer> getProfitHistory() { return profitHistory; }
}
