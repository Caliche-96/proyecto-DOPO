package silkRoad;

import java.util.List;

/**
 * Representa una tienda tipo "Fighter", la cual puede defenderse.
 * Solo los robots con más dinero acumulado (totalProfit) que la tienda
 * pueden robarle. Si ningún robot cumple esta condición, la tienda 
 * se protege reduciendo sus tenges a 1.
 */
public class FighterStore extends Store {

    /**
     * Constructor de la tienda Fighter.
     *
     * @param x coordenada X de la celda
     * @param y coordenada Y de la celda
     * @param tenges dinero inicial de la tienda
     * @param size tamaño de celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color de la tienda
     */
    public FighterStore(int x, int y, int tenges, int size, int offsetX, int offsetY, String color) {
        super(x, y, tenges, size, offsetX, offsetY, color);
    }

    /**
     * Evalúa si la tienda debe protegerse.
     * Si ningún robot tiene más dinero acumulado que la tienda,
     * la tienda reduce sus tenges a 1 como medida de defensa.
     *
     * @param robots lista de robots actuales en el sistema
     */

     @Override
    public void evaluateDefense(List<Robot> robots) {
        boolean vulnerable = false;

        // Revisa si hay algún robot más rico que la tienda
        for (Robot r : robots) {
            if (r.getTotalProfit() > this.getTenges()) {
                vulnerable = true;
                break;
            }
        }

        // Si ningún robot puede vencerla, la tienda se protege
        if (!vulnerable) {
            setTenges(1);
            System.out.println("La FighterStore (" + getColor() +
                    ") se protegió reduciendo sus tenges a 1.");
        }
    }
}
