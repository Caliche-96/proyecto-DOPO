package silkRoad;
import java.util.HashMap;
import java.util.Map;


import java.util.HashMap;
import java.util.Map;

/**
 * La clase {@code SpiralPath} proporciona utilidades para generar
 * coordenadas que recorren un tablero de tamaño {@code n x n} en forma
 * de espiral, empezando desde la esquina superior izquierda (0,0).
 */
public class SpiralPath {
    /**
     * Genera las coordenadas (x, y) que recorren un tablero de {@code n x n}
     * en forma de espiral.  
     * @param n tamaño del tablero (número de casillas por lado).          
     * @return path
     */
    public static int[][] generateSpiral(int n) {
        int[][] path = new int[n * n][2];
        boolean[][] visited = new boolean[n][n];

        // Movimientos en el orden: derecha, abajo, izquierda, arriba
        int[] dx = {1, 0, -1, 0};
        int[] dy = {0, 1, 0, -1};

        int x = 0, y = 0, dir = 0; // posición inicial y dirección actual

        for (int i = 0; i < n * n; i++) {
            path[i][0] = x;
            path[i][1] = y;
            visited[y][x] = true;

            int nx = x + dx[dir];
            int ny = y + dy[dir];

            // Cambiar dirección si se sale del tablero o la celda ya fue visitada
            if (nx < 0 || nx >= n || ny < 0 || ny >= n || visited[ny][nx]) {
                dir = (dir + 1) % 4; // girar a la derecha (sentido horario)
                nx = x + dx[dir];
                ny = y + dy[dir];
            }

            x = nx;
            y = ny;
        }

        return path;
    }

    /**
     * Genera un mapa que asocia cada número de casilla con sus coordenadas
     * en el recorrido espiral correspondiente a un tablero de {@code n x n}.
     * 
     * @param n tamaño del tablero (número de casillas por lado).
     * @return map
     */
    public static Map<Integer, int[]> generateSpiralMap(int n) {
        int[][] spiral = generateSpiral(n);
        Map<Integer, int[]> map = new HashMap<>();

        for (int i = 0; i < spiral.length; i++) {
            map.put(i, new int[]{spiral[i][0], spiral[i][1]});
        }

        return map;
    }
}

