package silkRoad;
import Shapes.*;
/**
 * Clase SilkRoadContest
 * Ejecuta la simulación automática de varios días con datos de entrada.
 * Usa la clase SilkRoad y coordina los eventos del maratón.
 */
public class SilkRoadContest {

    /**
     * Simula el concurso SilkRoad con la matriz de días dada.
     * @param days arreglo de días con acciones
     * @param slow si es true añade pausas visuales entre días
     */
    public void simulate(int[][] days, boolean slow) {
        System.out.println("=== INICIO DE SIMULACIÓN ===");
        SilkRoad sr = new SilkRoad(10); // tablero 10x10

        for (int i = 0; i < days.length; i++) {
            int[] day = days[i];
            System.out.println("\n--- Día " + (i + 1) + " ---");

            // 1) Procesar entrada: colocar robot o tienda
            try {
                if (day[0] == 1) {
                    // Colocar robot sin tipo (por defecto)
                    sr.placeRobot(day[1]);
                } else if (day[0] == 2) {
                    // Colocar tienda sin tipo (por defecto)
                    sr.placeStore(day[1], day[2]);
                }
            } catch (SilkRoadException e) {
                System.err.println("Error en el día " + (i + 1) + ": " + e.getMessage());
            }

            // 2) Mover robots y calcular ganancia del día (NO lanzan excepción)
            sr.moveRobots();
            int dailyProfit = sr.dailyProfit();
            System.out.println("Ganancia del día " + (i + 1) + ": " + dailyProfit);

            // 3) Reabastecer tiendas y reiniciar robots (NO lanzan excepción)
            sr.reboot();

            if (slow) {
                Canvas.getCanvas().wait(2000);
            }
        }

        // ========================
        //   RESUMEN FINAL
        // ========================
        System.out.println("\n=== RESUMEN DE LA SIMULACIÓN ===");
        // Métodos que NO lanzan excepción, no van en try/catch
        sr.emptiedStores();
        sr.profitPerMove();

        System.out.println("\n=== FIN DE LA SIMULACIÓN ===");
    }

    /**
     * Método principal para ejecutar la simulación del maratón.
     */
    public static void solve(String[] args) {
        int[][] days = {
            {1, 20},      // Día 1: robot en casilla 20
            {2, 15, 15},  // Día 2: tienda en 15 con 15 tenges
            {2, 40, 50},  // Día 3: tienda en 40 con 50 tenges
            {1, 50},      // Día 4: robot en 50
            {2, 80, 20},  // Día 5: tienda en 80 con 20 tenges
            {2, 70, 30}   // Día 6: tienda en 70 con 30 tenges
        };

        SilkRoadContest contest = new SilkRoadContest();
        contest.simulate(days, true);
    }
}
