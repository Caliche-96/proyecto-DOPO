package silkRoad;

/**
 * Clase NeverbackRobot — un tipo de robot que nunca regresa a su posición inicial.
 * Hereda de Robot pero sobrescribe el método reset() para que no realice movimiento alguno.
 *
 * @author Alex
 */
public class NeverbackRobot extends Robot {

    /**
     * Constructor del robot tipo Neverback.
     *
     * @param xCell posición X (celda en el tablero)
     * @param yCell posición Y (celda en el tablero)
     * @param startIndex índice inicial en el camino en espiral
     * @param cellSize tamaño de la celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color del robot
     */
    public NeverbackRobot(int xCell, int yCell, int startIndex,
                          int cellSize, int offsetX, int offsetY, String color) {
        super(xCell, yCell, startIndex, cellSize, offsetX, offsetY, color);
    }

    /**
     * Sobrescribe el método reset para que este tipo de robot nunca se devuelva.
     */
    @Override
    public void reset() {
        System.out.println("Robot Neverback (" + getColor() + ") no regresa a su posición inicial.");
        // No hace nada intencionadamente
    }
}
