package silkRoad.test;

import silkRoad.*;

/**
 * Clase SilkRoadAcceptance
 * 
 * Contiene las pruebas de aceptación (simulaciones visuales)
 * para verificar el comportamiento de las tiendas y robots extendidos.
 * 
 * Cada método representa una simulación visual independiente
 * que debe observarse directamente en el Canvas.
 */
public class SilkRoadAcceptance {

    /**
     * Prueba de aceptación: AutonomousStore.
     * 
     * Crea tres tiendas autónomas que deben ubicarse aleatoriamente
     * sin respetar la casilla indicada.
     */
    public static void testAutonomousStore() {
        System.out.println("\n===== PRUEBA DE ACEPTACIÓN: AUTONOMOUS STORE =====");
        SilkRoad sr = new SilkRoad(10);

        try {
            sr.placeStore(10, 50, "autonomous");
            sr.placeStore(25, 60, "autonomous");
            sr.placeStore(40, 70, "autonomous");
            sr.stores();

            System.out.println("Observe el Canvas: las tiendas aparecen en posiciones aleatorias.");
        } catch (Exception e) {
            System.out.println("Error durante la prueba: " + e.getMessage());
        }
    }

    /**
     * Prueba de aceptación: FighterStore.
     * 
     * Crea una tienda fighter una tienda normal y un robots
     * se simulan varios dias y el robot no roba la tienda fighter hasta no tener mayor cantidad
     * de tengues que la tienda
     */
    public static void testFighterStore1() {
        System.out.println("\n===== PRUEBA DE ACEPTACIÓN: FIGHTER STORE =====");
        SilkRoad sr = new SilkRoad(10);

        try {
            sr.placeStore(35, 30);
            sr.placeRobot(20);
            sr.moveRobots(); 
            
            sr.reboot();
            
            sr.placeStore(25, 50, "fighter");   
            
            sr.moveRobots(); 
            
            sr.reboot();
            sr.moveRobots(); 
            
            sr.reboot();
            sr.moveRobots(); 
            
            sr.reboot();
            sr.moveRobots(); 
            
            sr.profitPerMove();

            System.out.println("El robot creado no vacia la tienda fighter hasta tener mas tengues que ella ");
        } catch (Exception e) {
            System.out.println("Error durante la prueba: " + e.getMessage());
        }
    }
    

    /**
     * Prueba de aceptación: LuckyRobot.
     * 
     * Cada movimiento puede duplicar la ganancia o perder la mitad.
     */
    public static void testLuckyRobot() {
        System.out.println("\n===== PRUEBA DE ACEPTACIÓN: LUCKY ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        try {
            sr.placeStore(25, 40);
            sr.placeRobot(10, "lucky");

            for (int day = 1; day <= 3; day++) {
                System.out.println("\n--- Día " + day + " ---");
                sr.moveRobots();
                sr.reboot();
            }

            sr.profitPerMove();
        } catch (Exception e) {
            System.out.println("Error durante la prueba: " + e.getMessage());
        }
    }

    /**
     * Prueba de aceptación: NeverbackRobot.
     * 
     * Verifica que este robot no regresa a su posición inicial en el reboot.
     */
    public static void testNeverbackRobot() {
        System.out.println("\n===== PRUEBA DE ACEPTACIÓN: NEVERBACK ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        try {
            sr.placeStore(30, 50);
            sr.placeRobot(10, "neverback");

            sr.moveRobots();
            
            int startIndex = 30; 
            int targetIndex = startIndex + 10; 
            sr.moveRobot(startIndex, targetIndex);
            sr.reboot(); 

            System.out.println("El robot Neverback debe permanecer en su última posición.");
        } catch (Exception e) {
            System.out.println("Error durante la prueba: " + e.getMessage());
        }
    }

    /**
     * Prueba de aceptación: TenderRobot.
     * 
     * Verifica que el robot solo toma la mitad del dinero de las tiendas que visita.
     */
    public static void testTenderRobot() {
        System.out.println("\n===== PRUEBA DE ACEPTACIÓN: TENDER ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        try {
            sr.placeStore(25, 100);
            sr.placeRobot(10, "tender");

            sr.moveRobots();
            sr.profitPerMove();

            System.out.println("El robot Tender debe mostrar ganancias reducidas a la mitad en la consola.");
        } catch (Exception e) {
            System.out.println("Error durante la prueba: " + e.getMessage());
        }
    }

    /**
     * Método main para ejecutar todas las pruebas de aceptación.
     */
    public static void main(String[] args) {
        testAutonomousStore();
        testFighterStore1();
        testLuckyRobot();
        testNeverbackRobot();
        testTenderRobot();
    }
}
