package silkRoad.test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import silkRoad.SilkRoad;

/**
 * Pruebas unitarias para la clase SilkRoad.
 * 
 * Cada método valida un aspecto específico del comportamiento del simulador.
 * Compatibles con JUnit 4 (versión usada por BlueJ).
 * 
 * @author Alex
 */
public class SilkRoadTest {

    private SilkRoad road;

    /**
     * Se ejecuta antes de cada prueba.
     * Inicializa un tablero de 10x10 para todas las pruebas.
     */
    @Before
    public void setUp() {
        road = new SilkRoad(10);
    }

    /**
     * Verifica que el constructor principal funcione correctamente.
     */
    @Test
    public void testConstructorLength() {
        assertNotNull("El constructor con tamaño debe crear un objeto válido", road);
    }

    /**
     * Verifica el constructor alternativo con matriz de días.
     */
    @Test
    public void testConstructorDays() {
        int[][] days = {{1, 2}, {3, 4}};
        SilkRoad sr = new SilkRoad(days);
        assertNotNull("El constructor alternativo debe crear un objeto válido", sr);
    }

    /**
     * Verifica la creación de una tienda normal en una casilla específica.
     */
    @Test
    public void testPlaceStore() throws Exception {
        road.placeStore(5, 50);
        assertEquals("Debe existir una tienda colocada", 1, road.stores().length);
    }

    /**
     * Verifica la creación de una tienda especial (fighter o autonomous).
     */
    @Test
    public void testPlaceStoreStore() throws Exception {
        road.placeStore(5, 40, "fighter");
        assertEquals("Debe existir una tienda especial creada", 1, road.stores().length);
    }

    /**
     * Verifica que se pueda eliminar una tienda correctamente.
     */
    @Test
    public void testRemoveStore() throws Exception {
        road.placeStore(4, 60);
        boolean removed = road.removeStore(4);
        assertTrue("La tienda debe ser eliminada correctamente", removed);
    }

    /**
     * Verifica la creación de un robot normal.
     */
    @Test
    public void testPlaceRobot() throws Exception {
        road.placeRobot(3);
        assertEquals("Debe existir un robot en el tablero", 1, road.robots().length);
    }

    /**
     * Verifica la creación de un robot de tipo especial (neverback, tender, lucky...).
     */
    @Test
    public void testPlaceRobotType() throws Exception {
        road.placeRobot(2, "lucky");
        assertEquals("Debe existir un robot especial en el tablero", 1, road.robots().length);
    }

    /**
     * Verifica la eliminación de un robot en una casilla específica.
     */
    @Test
    public void testRemoveRobot() throws Exception {
        road.placeRobot(6);
        boolean removed = road.removeRobot(6);
        assertTrue("El robot debe eliminarse correctamente", removed);
    }

    /**
     * Verifica el proceso de movimiento de robots y el cálculo de ganancias.
     */
    @Test
    public void testMoveRobots() throws Exception {
        road.placeStore(5, 100);
        road.placeRobot(3);
        int profit = road.moveRobots();
        assertTrue("La ganancia del día debe ser mayor o igual a 0", profit >= 0);
    }

    /**
     * Verifica el movimiento manual de un robot entre casillas.
     */
    @Test
    public void testMoveRobotSpecific() throws Exception {
        road.placeRobot(1);
        road.moveRobot(1, 5);
        int[][] robots = road.robots();
        assertNotNull("El robot debe haberse movido correctamente", robots);
    }

    /**
     * Verifica el reabastecimiento de todas las tiendas.
     */
    @Test
    public void testResupplyStores() throws Exception {
        road.placeStore(2, 40);
        road.resupplyStores();
        assertEquals("Debe seguir existiendo una tienda reabastecida", 1, road.stores().length);
    }

    /**
     * Verifica el retorno de los robots a su posición inicial.
     */
    @Test
    public void testReturnRobots() throws Exception {
        road.placeRobot(7);
        road.returnRobots();
        assertEquals("Debe seguir existiendo un robot tras el retorno", 1, road.robots().length);
    }

    /**
     * Verifica el reinicio completo del sistema (reboot).
     */
    @Test
    public void testReboot() throws Exception {
        road.placeRobot(4);
        road.placeStore(8, 50);
        road.reboot();
        assertTrue("El sistema debe reiniciarse correctamente", road.ok());
    }

    /**
     * Verifica el cálculo total de la ganancia acumulada.
     */
    @Test
    public void testProfit() throws Exception {
        road.placeStore(3, 50);
        road.placeRobot(1);
        road.moveRobots();
        assertTrue("El profit total debe ser no negativo", road.profit() >= 0);
    }

    /**
     * Verifica la obtención de posiciones de tiendas.
     */
    @Test
    public void testStoresMethod() throws Exception {
        road.placeStore(5, 80);
        int[][] result = road.stores();
        assertEquals("Debe devolver las coordenadas de las tiendas", 1, result.length);
    }

    /**
     * Verifica la información de las tiendas vaciadas.
     */
    @Test
    public void testEmptiedStores() throws Exception {
        road.placeStore(5, 90);
        int[][] result = road.emptiedStores();
        assertNotNull("Debe devolver una matriz válida con tiendas vaciadas", result);
    }

    /**
     * Verifica la obtención de posiciones de robots.
     */
    @Test
    public void testRobotsMethod() throws Exception {
        road.placeRobot(2);
        int[][] result = road.robots();
        assertEquals("Debe devolver las coordenadas de los robots", 1, result.length);
    }

    /**
     * Verifica el registro de ganancias por movimiento de cada robot.
     */
    @Test
    public void testProfitPerMove() throws Exception {
        road.placeStore(4, 70);
        road.placeRobot(2);
        road.moveRobots();
        int[][] result = road.profitPerMove();
        assertNotNull("Debe devolver la matriz de ganancias por movimiento", result);
    }

    /**
     * Verifica que todos los elementos puedan hacerse visibles correctamente.
     */
    @Test
    public void testMakeVisible() {
        road.makeVisible();
        assertTrue("El tablero debe poder hacerse visible", road.ok());
    }

    /**
     * Verifica que todos los elementos puedan hacerse invisibles correctamente.
     */
    @Test
    public void testMakeInvisible() {
        road.makeInvisible();
        assertTrue("El tablero debe poder hacerse invisible sin errores", true);
    }

    /**
     * Verifica el estado del sistema (ok flag).
     */
    @Test
    public void testOk() {
        assertTrue("El sistema debe estar en estado OK", road.ok());
    }
}