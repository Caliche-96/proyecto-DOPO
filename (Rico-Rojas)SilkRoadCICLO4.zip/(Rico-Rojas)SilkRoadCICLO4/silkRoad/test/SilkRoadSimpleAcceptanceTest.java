package silkRoad.test;


import org.junit.Test;
import static org.junit.Assert.*;
import silkRoad.*;

/**
 * Pruebas de aceptación simples e independientes para cada tipo
 * de tienda y robot extendido en el simulador SilkRoad.
 */
public class SilkRoadSimpleAcceptanceTest {

    /**
     * Prueba de aceptación: AutonomousStore.
     * Debe colocarse en una posición aleatoria sin usar la ubicación dada.
     */
    @Test
    public void testAutonomousStore() throws Exception {
        System.out.println("\n===== TEST: AUTONOMOUS STORE =====");
        SilkRoad sr = new SilkRoad(10);

        sr.placeStore(15, 50, "autonomous");
        int[][] stores = sr.stores();

        assertTrue("Debe existir al menos una tienda", stores.length > 0);
        assertNotEquals("La tienda no debe estar en la casilla 15 (elige posición aleatoria)",
                        15, sr.findSpiralIndex(stores[0][0], stores[0][1]));

        System.out.println("AutonomousStore se colocó correctamente en casilla aleatoria.");
    }

    /**
     * Prueba de aceptación: FighterStore.
     * Solo puede ser robada si un robot tiene más profit total que ella.
     */
    @Test
    public void testFighterStore() throws Exception {
        System.out.println("\n===== TEST: FIGHTER STORE =====");
        SilkRoad sr = new SilkRoad(10);

        sr.placeStore(8, 100, "fighter");
        sr.placeRobot(2); // robot normal con poco profit

        int profit1 = sr.moveRobots();
        System.out.println("Ganancia día 1: " + profit1);

        assertTrue("El sistema debe seguir correcto", sr.ok());
        assertTrue("Ganancia no negativa", profit1 >= 0);

        System.out.println("FighterStore se defendió correctamente si el robot tenía poco profit.");
    }

    /**
     * Prueba de aceptación: LuckyRobot.
     * Puede duplicar o reducir a la mitad su ganancia.
     */
    @Test
    public void testLuckyRobot() throws Exception {
        System.out.println("\n===== TEST: LUCKY ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        sr.placeStore(5, 50);
        sr.placeRobot(2, "lucky");

        int profit = sr.moveRobots();
        System.out.println("Ganancia obtenida por LuckyRobot: " + profit);

        assertTrue("La ganancia del LuckyRobot debe ser >= 0", profit >= 0);
        System.out.println("LuckyRobot completó su turno con resultado variable.");
    }

    /**
     * Prueba de aceptación: NeverbackRobot.
     * Este robot nunca debe volver a su posición inicial después de un reboot.
     */
    @Test
    public void testNeverbackRobot() throws Exception {
        System.out.println("\n===== TEST: NEVERBACK ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        sr.placeStore(6, 40);
        sr.placeRobot(2, "neverback");

        int[][] before = sr.robots();
        int profit = sr.moveRobots();
        System.out.println("Ganancia día 1: " + profit);

        sr.reboot();
        int[][] after = sr.robots();

        assertNotEquals("El NeverbackRobot no debe volver a su posición inicial",
                        before[0][0], after[0][0]);
        System.out.println("NeverbackRobot permaneció en su nueva posición tras reboot.");
    }

    /**
     * Prueba de aceptación: TenderRobot.
     * Solo toma la mitad del dinero de las tiendas que visita.
     */
    @Test
    public void testTenderRobot() throws Exception {
        System.out.println("\n===== TEST: TENDER ROBOT =====");
        SilkRoad sr = new SilkRoad(10);

        sr.placeStore(5, 60);
        sr.placeRobot(3, "tender");

        int profit = sr.moveRobots();
        System.out.println("Ganancia registrada: " + profit);

        assertTrue("El profit debe ser menor que el dinero de la tienda (toma la mitad)",
                   profit < 60);
        System.out.println("TenderRobot funcionó correctamente (ganancia parcial).");
    }
}