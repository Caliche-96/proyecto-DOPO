package silkRoad;

/**
 * Clase TenderRobot — un tipo especial de robot que solo toma la mitad del dinero
 * de las tiendas que visita. Hereda de Robot y ajusta su ganancia al 50%.
 *
 * 
 */
public class TenderRobot extends Robot {

    /**
     * Constructor del robot tipo Tender.
     *
     * @param xCell posición X (celda en el tablero)
     * @param yCell posición Y (celda en el tablero)
     * @param startIndex índice inicial en el camino en espiral
     * @param cellSize tamaño de la celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color del robot
     */
    public TenderRobot(int xCell, int yCell, int startIndex,
                       int cellSize, int offsetX, int offsetY, String color) {
        super(xCell, yCell, startIndex, cellSize, offsetX, offsetY, color);
    }

    /**
     * Sobrescribe el método addProfit para que el robot solo gane la mitad.
     *
     * @param profit ganancia total disponible en la tienda
     */
    @Override
    public void addProfit(int profit) {
        int halfProfit = profit / 2; // gana solo la mitad
        super.addProfit(halfProfit);
        System.out.println("Robot Tender (" + getColor() + ") ganó solo la mitad: " + halfProfit + " tenges.");
    }
}
