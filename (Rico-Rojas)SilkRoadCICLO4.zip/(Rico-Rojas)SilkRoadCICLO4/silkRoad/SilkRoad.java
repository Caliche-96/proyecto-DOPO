package silkRoad;

import java.util.*;
import Shapes.*;

/**
 * Clase principal que controla la simulación SilkRoad.
 * Gestiona el tablero, tiendas, robots y ganancias por día.
 */
public class SilkRoad { 
    private Board board; 
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int[][] spiralPath;
    private Map<Integer, int[]> cellMap;
    private boolean visible;
    private boolean ok;
    private Random rnd;
    private List<String> robotColors;
    private List<String> storeColors;
    
    //-------Constructores (Ciclos) ---------------------------
        
    /**
     * Constructor Principal 
     * Crea un nuevo simulador SilkRoad con un tablero cuadrado de tamaño length x length.
     * @param length tamaño del tablero
     */
    public SilkRoad(int length) {
        this.board = new Board(length, 30, 10, 10);
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.spiralPath = SpiralPath.generateSpiral(length);
        this.cellMap = SpiralPath.generateSpiralMap(length);
        this.visible = true;
        this.ok = true;
        this.rnd = new Random();

        List<String> baseColors = Arrays.asList(
        "red", "blue", "green", "yellow","magenta", "orange",
        "cyan", "pink", "gray", "lightGray", "darkGray",
        "purple", "lime", "teal", "brown", "gold", "silver",
        "turquoise", "violet", "indigo", "crimson", "salmon",
        "coral", "khaki", "plum", "navy", "olive", "orchid",
        "peach", "sky", "maroon");
        this.robotColors = new ArrayList<>(baseColors);
        this.storeColors = new ArrayList<>(baseColors);
    }
    
    /**
     * Constructor Alternativo
     * Inicializa el simulador con un conjunto de días predefinidos
     * Reutiliza la lógica del método simulate() de SilkRoadContest
     * @param days matriz de días y operaciones 
     */
    public SilkRoad(int[][] days) {
       
        this.board = new Board(10, 30, 10, 10);
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.spiralPath = SpiralPath.generateSpiral(board.getSize());
        this.cellMap = SpiralPath.generateSpiralMap(board.getSize());
        this.visible = true;
        this.ok = true;
        this.rnd = new Random();
    
        List<String> baseColors = Arrays.asList(
        "red", "blue", "green", "yellow","magenta", "orange",
        "cyan", "pink", "gray", "lightGray", "darkGray",
        "purple", "lime", "teal", "brown", "gold", "silver",
        "turquoise", "violet", "indigo", "crimson", "salmon",
        "coral", "khaki", "plum", "navy", "olive", "orchid",
        "peach", "sky", "maroon");
        this.robotColors = new ArrayList<>(baseColors);
        this.storeColors = new ArrayList<>(baseColors);
    
        SilkRoadContest contest = new SilkRoadContest();
        contest.simulate(days, true); 
    
        System.out.println("Simulación completada con " + days.length + " días usando el constructor alternativo.");
    }

    //------------Métodos Principales (Ciclos)---------------------------

    /**
     * Coloca una tienda en la ubicación dada
     * @param location número de casilla
     * @param tenges cantidad de tenges inicial
     * @throws SilkRoadException si la casilla es inválida o ya está ocupada
     */
    public void placeStore(int location, int tenges) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        int[] c = cellMap.get(location);
        if (!isCellFree(c[0], c[1])) {
            ok = false;
            throw new SilkRoadException(SilkRoadException.CELL_OCCUPIED);
        }
    
        String color = getUniqueColor(storeColors);
        stores.add(new Store(c[0], c[1], tenges, board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color));
        if (visible)
            System.out.println("Tienda creada en casilla " + location + " (" + color + ") con " + tenges + " tenges.");
    }
    
    
    /**
     * Coloca una tienda especial en la ubicación dada según su tipo.
     * Tipos válidos:
     *  - "autonomous": tienda que elige su propia posición en el tablero.
     *  - "fighter": tienda que solo puede ser robada por robots con más dinero que ella.
     *
     * @param location número de casilla donde se intentará colocar (solo aplica para fighter)
     * @param tenges cantidad de tenges inicial
     * @param type tipo de tienda ("autonomous" o "fighter")
     * @throws SilkRoadException si el tipo de tienda o la ubicación son inválidos
     */
    public void placeStore(int location, int tenges, String type) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        Store store = null;
        String color = getUniqueColor(storeColors);
    
        switch (type.toLowerCase()) {
            case "autonomous":
                Random rnd = new Random();
                int randomX = rnd.nextInt(board.getSize());
                int randomY = rnd.nextInt(board.getSize());
                store = new Store(randomX, randomY, tenges,
                        board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color);
                break;
    
            case "fighter":
                int[] coords = cellMap.get(location);
                store = new FighterStore(
                    coords[0],
                    coords[1],
                    tenges,
                    board.getCellSize(),
                    board.getOffsetX(),
                    board.getOffsetY(),
                    color
                );
                break;
    
            default:
                throw new SilkRoadException(SilkRoadException.INVALID_STORE_TYPE);
        }
    
        if (store != null) {
            stores.add(store);
            if (visible)
                System.out.println("Tienda especial tipo '" + type + "' creada (" + color + ") con " + tenges + " tenges.");
        }
    }
    
    
    /**
     * Elimina la tienda que esté en la casilla indicada 
     *
     * @param location número de casilla (índice en spiralPath)
     * @return true si se eliminó al menos una tienda, false si no había ninguna en esa casilla
     * @throws SilkRoadException si la casilla es inválida o no hay tiendas en ella
     */
    public boolean removeStore(int location) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        int[] coords = cellMap.get(location);
        int x = coords[0], y = coords[1];
    
        boolean removed = false;
        Iterator<Store> it = stores.iterator();
        while (it.hasNext()) {
            Store s = it.next();
            if (s.getXCell() == x && s.getYCell() == y) {
                s.makeInvisible();
                it.remove();
                removed = true;
            }
        }
    
        if (!removed)
            throw new SilkRoadException(SilkRoadException.NO_STORE_FOUND);
    
        return removed;
    }
    
    
    /**
     * Coloca un robot en la ubicación dada.
     * @param location número de casilla
     * @throws SilkRoadException si la casilla es inválida o está ocupada
     */
    public void placeRobot(int location) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        int[] c = cellMap.get(location);
        if (!isCellFree(c[0], c[1])) {
            ok = false;
            throw new SilkRoadException(SilkRoadException.CELL_OCCUPIED);
        }
    
        String color = getUniqueColor(robotColors);
        int idx = findSpiralIndex(c[0], c[1]);
        robots.add(new Robot(c[0], c[1], idx, board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color));
    
        if (visible)
            System.out.println("Robot creado en casilla " + location + " (" + color + ")");
    }
    
    
    /**
     * Coloca un robot en la ubicación dada según su tipo.
     * Tipos posibles:
     * 
     *  - "neverback": robot que nunca retrocede
     *  - "tender": robot que toma sólo la mitad del dinero de las tiendas
     *  - "lucky" : representa un robot con comportamiento aleatorio al ganar dinero
     *
     * @param location número de casilla donde se colocará
     * @param type tipo de robot ("neverback", "tender","lucky")
     * @throws SilkRoadException si el tipo de robot o la ubicación son inválidos
     */
    public void placeRobot(int location, String type) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        int[] c = cellMap.get(location);
    
        if (!isCellFree(c[0], c[1])) {
            ok = false;
            throw new SilkRoadException(SilkRoadException.CELL_OCCUPIED);
        }
    
        String color = getUniqueColor(robotColors);
        int idx = findSpiralIndex(c[0], c[1]);
        Robot robot;
    
        switch (type.toLowerCase()) {
            case "neverback":
                robot = new NeverbackRobot(c[0], c[1], idx,
                        board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color);
                if (visible)
                    System.out.println("Robot Neverback creado en casilla " + location + " (" + color + ")");
                break;
    
            case "tender":
                robot = new TenderRobot(c[0], c[1], idx,
                        board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color);
                if (visible)
                    System.out.println("Robot Tender creado en casilla " + location + " (" + color + ")");
                break;
    
            case "lucky":
                robot = new LuckyRobot(c[0], c[1], idx,
                        board.getCellSize(), board.getOffsetX(), board.getOffsetY(), color);
                if (visible)
                    System.out.println("Robot Lucky creado en casilla " + location + " (" + color + ")");
                break;
    
            default:
                throw new SilkRoadException(SilkRoadException.INVALID_ROBOT_TYPE);
        }
    
        robots.add(robot);
    }
    
    
    /**
     * Elimina el robot que esté en la casilla indicada (según el mapa en espiral).
     *
     * @param location número de casilla (índice en spiralPath)
     * @return true si se eliminó al menos un robot, false si no había ninguno en esa casilla
     * @throws SilkRoadException si la casilla es inválida o no hay robots
     */
    public boolean removeRobot(int location) throws SilkRoadException {
        if (!cellMap.containsKey(location))
            throw new SilkRoadException(SilkRoadException.INVALID_CELL);
    
        int[] coords = cellMap.get(location);
        int x = coords[0], y = coords[1];
    
        boolean removed = false;
        Iterator<Robot> it = robots.iterator();
        while (it.hasNext()) {
            Robot r = it.next();
            if (r.getXCell() == x && r.getYCell() == y) {
                r.makeInvisible();
                it.remove();
                removed = true;
            }
        }
    
        if (!removed)
            throw new SilkRoadException(SilkRoadException.NO_ROBOT_FOUND);
    
        return removed;
    }

    
    
    //________Método moveRobots con sus métodos auxiliares________________
    
    /**
     * Ejecuta los movimientos de los robots hacia las tiendas más rentables.
     * Divide la lógica en tres etapas: generar opciones, seleccionar asignaciones
     * y ejecutar los movimientos. Devuelve la ganancia total del día.
     *
     * @return ganancia total obtenida en la jornada
     */
    public int moveRobots() {
        evaluateFighterStores();
        List<MoveOption> options = generateMoveOptions();      // Opciones posibles 
        List<MoveOption> chosen = selectBestOptions(options);  // Opciones mas rentables 
        return executeMoves(chosen);                           // Ejecutar y calcular ganancias 
    }

    /**
     * Genera todas las combinaciones válidas robot–tienda con profit positivo.
     * 
     * @return lista de posibles movimientos con sus datos de profit y distancia
     */
    private List<MoveOption> generateMoveOptions() {
        List<MoveOption> options = new ArrayList<>();
        for (Robot r : robots) {
            int robotIdx = r.getSpiralIndex();
            for (Store s : stores) {
                if (s.getTenges() <= 0) continue;
                int storeIdx = findSpiralIndex(s.getXCell(), s.getYCell());
                if (storeIdx == -1) continue;
    
                int dist = Math.abs(robotIdx - storeIdx);
                int profit = s.getTenges() - dist;
                if (profit > 0) options.add(new MoveOption(r, s, profit, dist, storeIdx));
            }
        }
    
        // Ordenar: mayor profit primero, menor distancia en caso de empate
        options.sort((a, b) -> {
            if (b.profit != a.profit) return b.profit - a.profit;
            return a.dist - b.dist;
        });
    
        return options;
    }

    /**
     * Filtra las mejores combinaciones robot–tienda, evitando repetir robots o tiendas.
     *
     * @param options lista de todas las combinaciones posibles
     * @return lista final de movimientos a ejecutar
     */
    private List<MoveOption> selectBestOptions(List<MoveOption> options) {
        Set<Robot> usedRobots = new HashSet<>();
        Set<Store> usedStores = new HashSet<>();
        List<MoveOption> chosen = new ArrayList<>();
    
        for (MoveOption opt : options) {
            if (usedRobots.contains(opt.robot) || usedStores.contains(opt.store)) continue;
            if (opt.store.getTenges() <= 0) continue;
    
            chosen.add(opt);
            usedRobots.add(opt.robot);
            usedStores.add(opt.store);
        }
    
        return chosen;
    }
    
    /**
     * Mueve los robots seleccionados, actualiza ganancias, vacía tiendas y destaca al mejor robot.
     *
     * @param chosen lista de movimientos seleccionados
     * @return ganancia total obtenida
     */
    private int executeMoves(List<MoveOption> chosen) {
        int totalProfit = 0;
        Robot bestRobot = null;
        int bestProfit = -1;
    
        for (MoveOption opt : chosen) {
            opt.robot.moveAlongSpiral(opt.storeIndex, spiralPath);
            opt.robot.addProfit(opt.profit);
            int realProfit = opt.robot.getLastProfit();
            opt.store.collect();
    
            System.out.println("Robot de color " + opt.robot.getColor() +
                               " llegó a tienda con profit " + realProfit);
    
            totalProfit += realProfit;
    
            
            if (realProfit > bestProfit) {
                bestProfit = realProfit;
                bestRobot = opt.robot;
            }
        }
    
        if (bestRobot != null) {
            System.out.println("El robot " + bestRobot.getColor() +
                               " obtuvo la mayor ganancia del día: " + bestProfit);
            bestRobot.blink(3);
        }
    
        return totalProfit;
    }

    /**
     * Clase auxiliar interna para representar una opción de movimiento.
     */
    private static class MoveOption {
        Robot robot;
        Store store;
        int profit;
        int dist;
        int storeIndex;
    
        MoveOption(Robot r, Store s, int profit, int dist, int storeIndex) {
            this.robot = r;
            this.store = s;
            this.profit = profit;
            this.dist = dist;
            this.storeIndex = storeIndex;
        }
    }

    //____________Fin MoveRobots()__________________________________________________
    
    /**
     * Mueve un robot desde su ubicación actual hasta otra casilla dada.
     * @param start índice inicial
     * @param target índice destino
     */
    public void moveRobot(int start, int target) {
        for (Robot r : robots) {
            if (r.getSpiralIndex() == start) {
                r.moveAlongSpiral(target, spiralPath);
                break;
            }
        }
    }

    /**
     * Reabastece todas las tiendas del tablero.
     */
    public void resupplyStores() {
        for (Store s : stores) s.resupply();
    }

    /**
     * Devuelve todos los robots a su posición inicial.
     */
    public void returnRobots() {
        for (Robot r : robots) r.reset();
    }

    /**
     * Reboot: resetea el día (reabastece tiendas y devuelve robots).
     */
    public void reboot() {
        resupplyStores();
        returnRobots();
        if (visible) System.out.println("Sistema reiniciado.");
    }

    /**
     * Calcula y devuelve la ganancia total acumulada.
     * @return ganancia total
     */
    public int profit() {
        int sum = 0;
        for (Robot r : robots) sum += r.getTotalProfit();
        return sum;
    }
    
    /**
     * Devuelve la posición de todas las tiendas.
     * @return Matriz con coordenadas [x, y] de cada tienda.
     */
    public int[][] stores() {
        int[][] data = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            data[i][0] = stores.get(i).getXCell();
            data[i][1] = stores.get(i).getYCell();
        }
        // Mostrar tiendas en consola
        System.out.println("\n=== Tiendas actuales ===");
        for (Store s : stores) {
            int casilla = findSpiralIndex(s.getXCell(), s.getYCell());
            System.out.println("Tienda " + s.getColor() + " → (casilla " + casilla + ")");
        }
        
        return data;
    }
    
    /**
     * Muestra las tiendas ordenadas por localización con la cantidad de veces que fueron vaciadas.
     * 
     * @return matriz con [location, timesEmptied]
     */
    public int[][] emptiedStores() {
        int[][] data = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            int loc = findSpiralIndex(stores.get(i).getXCell(), stores.get(i).getYCell());
            data[i][0] = loc;
            data[i][1] = stores.get(i).getTimesEmptied();
        }
        // Ordenar por localización
        Arrays.sort(data, Comparator.comparingInt(a -> a[0]));
        System.out.println("\n=== Tiendas vaciadas ===");
        for (int[] entry : data) {
            System.out.println("Tienda en casilla " + entry[0] + " fue vaciada " + entry[1] + " veces.");
        }
        return data;
    }
    
    /**
     * Devuelve la posición de todos los robots.
     * @return Matriz con coordenadas [x, y] de cada robot.
     */
    public int[][] robots() {
        int[][] data = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            data[i][0] = robots.get(i).getXCell();
            data[i][1] = robots.get(i).getYCell();
        }
        // Mostrar robots en consola
        System.out.println("\n=== Robots actuales ===");
        for (Robot r : robots) {
            int casilla = findSpiralIndex(r.getXCell(), r.getYCell());
            System.out.println("Robot " + r.getColor() + " → (casilla " + casilla + ")");
        }        
        return data;
    }

    /**
     * Muestra el profit obtenido por cada robot en cada día, ordenado por localización,
     * junto con la ganancia total acumulada y el color del robot.
     *
     * @return matriz [location, profits]
     */
    public int[][] profitPerMove() {
        int[][] data = new int[robots.size()][];
    
        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            int loc = findSpiralIndex(r.getXCell(), r.getYCell());
            List<Integer> moves = r.getProfitHistory();
    
            data[i] = new int[moves.size() + 1];
            data[i][0] = loc;
            for (int j = 0; j < moves.size(); j++) {
                data[i][j + 1] = moves.get(j);
            }
        }
        // Ordenar por localización
        Arrays.sort(data, Comparator.comparingInt(a -> a[0]));
        System.out.println("\n=== Ganancias por día ===");
        for (int i = 0; i < data.length; i++) {
            Robot r = robots.get(i);
            int[] entry = data[i];
            int total = 0;
    
            System.out.print("Robot en casilla " + entry[0] +
                             " (color " + r.getColor() + ") → ");
            for (int j = 1; j < entry.length; j++) {
                System.out.print("Mov" + j + ": " + entry[j] + "  ");
                total += entry[j];
            }
            System.out.println("| Total: " + total);
        }
        return data;
    }
    
    /**
     * Hace visibles nuevamente todos los elementos del simulador
     * (tablero, tiendas y robots).
     */
    public void makeVisible() {
        visible = true;
        // Mostrar tablero
        board.makeVisible();
        // Mostrar tiendas y robots existentes
        for (Store s : stores) {
            s.makeVisible();
        }
        for (Robot r : robots) {
            r.makeVisible();
        }
    }
    
    
    /**
     * Oculta todos los elementos del simulador (tablero, tiendas y robots),
     * sin cerrar la ventana del Canvas.
     */
    public void makeInvisible() {
        visible = false;
        // Ocultar tablero
        board.makeInvisible();
        // Ocultar tiendas y robots existentes
        for (Store s : stores) {
            s.makeInvisible();
        }
        for (Robot r : robots) {
            r.makeInvisible();
        }
    }
    
    /**
     * Finaliza la simulación y cierra el programa.
     */
    public void finish() {
        if (visible) Popup.show("Simulación finalizada.");
        System.exit(0);
    }

    /** 
     * Indica si la última operación fue correcta 
     */
    public boolean ok() { 
        return ok; 
    }
    
    //------Métodos Auxiliares-------------------
    
    /**
     * Calcula la ganancia total del día actual sumando la última ganancia de cada robot.
     * @return la ganancia total obtenida en el día
     */
    public int dailyProfit() {
        int sum = 0;
        for (Robot r : robots) {
            sum += r.getLastProfit();
        }
        return sum;
    }

    /**
     * Verifica si una celda está libre.
     */
    private boolean isCellFree(int x, int y) {
        for (Store s : stores)
            if (s.getXCell() == x && s.getYCell() == y) return false;
        for (Robot r : robots)
            if (r.getXCell() == x && r.getYCell() == y) return false;
        return true;
    }

    /**
     * Busca el índice de espiral correspondiente a las coordenadas dadas.
     */
    public int findSpiralIndex(int x, int y) {
        for (int i = 0; i < spiralPath.length; i++)
            if (spiralPath[i][0] == x && spiralPath[i][1] == y) return i;
        return -1;
    }
    
    /**
     * Asigna un color único disponible
     * @param available lista de colores
     * @return color asignado
     */
    private String getUniqueColor(List<String> available) {
        if (available.isEmpty()) available.addAll(Arrays.asList(
        "red", "blue", "green", "yellow", "magenta", "orange",
        "cyan", "pink", "gray", "lightGray", "darkGray",
        "purple", "lime", "teal", "brown", "gold", "silver",
        "turquoise", "violet", "indigo", "crimson", "salmon",
        "coral", "khaki", "plum", "navy", "olive", "orchid",
        "peach", "sky", "maroon"));
        String color = available.remove(rnd.nextInt(available.size()));
        return color;
    }
    
    /**
     * Evalúa todas las tiendas para aplicar sus defensas o estrategias internas.
     */
    public void evaluateFighterStores() {
        for (Store s : stores) {
            s.evaluateDefense(robots);  
        }
    }
}
