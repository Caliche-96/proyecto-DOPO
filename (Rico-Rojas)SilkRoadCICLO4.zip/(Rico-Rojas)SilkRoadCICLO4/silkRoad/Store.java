package silkRoad;
import Shapes.*;
import java.util.List;

/**
 * Clase que representa una tienda en el tablero de SilkRoad.
 * La tienda tiene una forma rectangular para su visualización.
 * Ya no extiende de Rectangle; ahora lo usa como atributo.
 */
public class Store {
    private Rectangle rectangle;
    protected int xCell;
    protected int yCell;
    private int initialTenges;
    private int tenges;
    private int timesEmptied;
    private String color;
    private String originalColor;

    /**
     * Crea una nueva tienda en una posición del tablero.
     *
     * @param xCell posición X de la celda
     * @param yCell posición Y de la celda
     * @param tenges cantidad inicial de tenges
     * @param cellSize tamaño de cada celda
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color de la tienda
     */
    public Store(int xCell, int yCell, int tenges, int cellSize, int offsetX, int offsetY, String color) {
        this.rectangle = new Rectangle();
        this.xCell = xCell;
        this.yCell = yCell;
        this.initialTenges = tenges;
        this.tenges = tenges;
        this.color = color;
        this.originalColor = color;
        this.timesEmptied = 0;

        int size = cellSize - 5;
        int margin = (cellSize - size) / 2;

        rectangle.changeSize(size, size);
        rectangle.changeColor(color);
        rectangle.moveHorizontal(offsetX + xCell * cellSize + margin);
        rectangle.moveVertical(offsetY + yCell * cellSize + margin);
        rectangle.makeVisible();
    }

    /**
     * Vacía la tienda, restablece su color a blanco y cuenta el número de veces vaciada.
     */
    public void collect() {
        this.tenges = 0;
        this.timesEmptied++;
        rectangle.changeColor("white");
        this.color = "white";
    }

    /**
     * Reabastece la tienda devolviendo sus tenges y color original.
     */
    public void resupply() {
        this.tenges = initialTenges;
        if ("white".equals(this.color)) {
            this.color = this.originalColor;
            rectangle.changeColor(this.color);
        }
    }
    
    /**
     * Hace visible la representación gráfica de la tienda.
     */
    public void makeVisible() {
       rectangle.makeVisible();
    }
    
    /**
     * Hace invisible la representación gráfica de la tienda.
     */
    public void makeInvisible() {
        rectangle.makeInvisible();
    }

    // ---------- Getters ----------

    /**
     * @return posición X de la tienda
     */
    public int getXCell() { return xCell; }

    /**
     * @return posición Y de la tienda
     */
    public int getYCell() { return yCell; }

    /**
     * @return cantidad actual de tenges
     */
    public int getTenges() { return tenges; }

    /**
     * @return número de veces que la tienda ha sido vaciada
     */
    public int getTimesEmptied() { return timesEmptied; }

    /**
     * @return color actual de la tienda
     */
    public String getColor() { return color; }
    
    /**
     * Asigna un nuevo valor de tenges a la tienda.
     * @param value nuevo monto de dinero
     */
    public void setTenges(int value) {
        this.tenges = value;
    }
    
    public void evaluateDefense(List<Robot> robots) {
    // Por defecto las tiendas normales no hacen nada
    }
}

