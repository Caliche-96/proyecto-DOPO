package silkRoad;

import java.util.Random;

/**
 * Clase LuckyRobot.
 * Representa un robot con comportamiento aleatorio al ganar dinero.
 * 
 * Cada vez que obtiene una ganancia, lanza una "moneda de la suerte":
 * - Si sale cara (true), duplica su ganancia.
 * - Si sale sello (false), pierde la mitad.
 */
public class LuckyRobot extends Robot {

    /** Generador de números aleatorios para determinar la suerte */
    private Random rnd;

    /**
     * Constructor de LuckyRobot.
     * 
     * @param xCell posición X de la celda donde se coloca
     * @param yCell posición Y de la celda donde se coloca
     * @param spiralIndex índice de posición en la espiral
     * @param cellSize tamaño de las celdas del tablero
     * @param offsetX desplazamiento horizontal del tablero
     * @param offsetY desplazamiento vertical del tablero
     * @param color color visual del robot
     */
    public LuckyRobot(int xCell, int yCell, int spiralIndex, int cellSize, int offsetX, int offsetY, String color) {
        super(xCell, yCell, spiralIndex, cellSize, offsetX, offsetY, color);
        this.rnd = new Random();
    }

    /**
     * Sobrescribe el método addProfit para aplicar la "suerte".
     * 
     * Si el robot tiene suerte, duplica la ganancia.
     * Si no, solo obtiene la mitad.
     * 
     * @param profit ganancia original calculada
     */
    @Override
    public void addProfit(int profit) {
        boolean lucky = rnd.nextBoolean(); // true o false
        int adjustedProfit = lucky ? profit * 2 : profit / 2;

        super.addProfit(adjustedProfit);

        System.out.println("Robot Lucky (" + getColor() + ") fue " +
                (lucky ? "AFORTUNADO " : "DESAFORTUNADO ") +
                " y obtuvo " + adjustedProfit + " tenges.");
    }
}



