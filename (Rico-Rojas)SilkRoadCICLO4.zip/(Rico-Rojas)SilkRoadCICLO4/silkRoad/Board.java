package silkRoad;
import Shapes.*;
import java.util.ArrayList;

import java.util.ArrayList;

/**
 * La clase representa un tablero cuadrado de NxN casillas,
 * encargado de dibujar y gestionar visualmente una rejilla de celdas.
 * 
 * Cada celda está representada por dos rectángulos: uno para el fondo y otro
 * para el borde, lo que permite un efecto visual de cuadrícula.
 * 
 */
public class Board {

    /** Tamaño del tablero (número de casillas por lado). */
    private int size;

    /** Tamaño (en píxeles) de cada casilla. */
    private int cellSize;

    /** Lista que contiene los rectángulos que conforman las celdas del tablero. */
    private ArrayList<Rectangle> cells;

    /** Desplazamiento horizontal desde el borde izquierdo de la pantalla. */
    private int offsetX;

    /** Desplazamiento vertical desde el borde superior de la pantalla. */
    private int offsetY;

    /**
     * Crea un nuevo tablero de NxN casillas.
     * 
     * @param size     número de casillas por lado del tablero (N).
     * @param cellSize tamaño en píxeles de cada casilla.
     * @param offsetX  desplazamiento horizontal del tablero.
     * @param offsetY  desplazamiento vertical del tablero.
     */
    public Board(int size, int cellSize, int offsetX, int offsetY) {
        this.size = size;
        this.cellSize = cellSize;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.cells = new ArrayList<>();

        drawGrid();
        drawCellNumbersSpiral();
    }

    /**
     * Dibuja la rejilla completa del tablero generando los rectángulos
     * correspondientes a cada celda y sus bordes.
     * 
     */
    private void drawGrid() {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                // Celda de fondo (blanca)
                Rectangle outer = new Rectangle();
                outer.changeSize(cellSize, cellSize);
                outer.changeColor("white");
                outer.moveHorizontal(offsetX + col * cellSize);
                outer.moveVertical(offsetY + row * cellSize);
                outer.makeVisible();

                // Borde (negro)
                Rectangle border = new Rectangle();
                border.changeSize(cellSize - 1, cellSize - 1);
                border.changeColor("black");
                border.moveHorizontal(offsetX + col * cellSize + 1);
                border.moveVertical(offsetY + row * cellSize + 1);
                border.makeVisible();

                cells.add(outer);
                cells.add(border);
            }
        }
    }

    /**
     * Muestra visualmente todas las celdas del tablero.
     * 
     */
    public void makeVisible() {
        for (Rectangle cell : cells) {
            cell.makeVisible();
        }
    }

    /**
     * Oculta visualmente todas las celdas del tablero.
     * 
     */
    public void makeInvisible() {
        for (Rectangle cell : cells) {
            cell.makeInvisible();
        }
    }
    
    // GETTERS
    
    /**
     * Obtiene el tamaño del tablero (número de casillas por lado).
     * 
     * @return el número de casillas por lado del tablero.
     */
    public int getSize() {
        return size;
    }

    /**
     * Obtiene el tamaño (en píxeles) de cada casilla.
     * 
     * @return el tamaño de una casilla.
     */
    public int getCellSize() {
        return cellSize;
    }

    /**
     * Obtiene el desplazamiento horizontal del tablero.
     * 
     * @return desplazamiento horizontal desde el borde izquierdo.
     */
    public int getOffsetX() {
        return offsetX;
    }

    /**
     * Obtiene el desplazamiento vertical del tablero.
     * 
     * @return desplazamiento vertical desde el borde superior.
     */
    public int getOffsetY() {
        return offsetY;
    }
    
    /**
     * Dibuja los números de casilla siguiendo el orden del spiralPath.
     * Cada número se dibuja en la esquina superior izquierda de la celda.
     */
    public void drawCellNumbersSpiral() {
        Canvas canvas = Canvas.getCanvas();
        int[][] spiral = SpiralPath.generateSpiral(size); // path[i] = {x,y} para la casilla i
    
        // Ajustes de posición dentro de la celda (márgenes)
        int offsetTextX = 70;   // píxeles desde el borde izquierdo de la celda
        int offsetTextY = 30;  // píxeles desde el borde superior de la celda (baseline del texto)
    
        for (int i = 0; i < spiral.length; i++) {
            int cellX = spiral[i][0];
            int cellY = spiral[i][1];
    
            int drawX = offsetX + cellX * cellSize + offsetTextX;
            int drawY = offsetY + cellY * cellSize + offsetTextY;
    
            // color del texto: usa "white" por defecto (útil si las celdas son oscuras).
            // Si necesitas otro color, cámbialo aquí.
            canvas.drawString(String.valueOf(i), drawX, drawY, "white");
        }
    }



}


