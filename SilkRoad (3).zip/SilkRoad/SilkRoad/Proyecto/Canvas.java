/**
 * Clase que representa un lienzo o área de dibujo
 * Contiene formas geométricas básicas
 */
public class Canvas {
    // Circulo en el canvas
    private Circle circle;
    // Triángulo en el canvas  
    private Triangle triangle;
    // Rectángulo en el canvas
    private Rectangle rectangle;
    
    /**
     * Constructor por defecto del Canvas
     */
    public Canvas() {}
}
