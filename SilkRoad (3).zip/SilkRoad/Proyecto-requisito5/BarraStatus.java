import java.util.Set;

/**
 * Clase que muestra el estado actual de la simulación
 */
public class BarraStatus {
    //Conexion con la clase SilkRoad para obtención de datos
    private SkillRoad sr;
    // Ganancia total acumulada
    private int gananciaTotal;
    // Ganancia del día actual
    private int GananciaDia;
    // Día actual de la simulación
    private int Day;
    
    /**
     * Constructor de objetos de la clase BarraStatus
     *  @param Length que será la longitud del camino de seda
     */
    public BarraStatus();
    {
        this.sr = new Set(lenght);
    }
    /**
     * Actualiza las estadísticas de ganancia
     * @param Garancia Ganancia a añadir al total
     */
    public void update(int Garancia) {}
    
    /**
     * Muestra el estado actual en la interfaz
     */
    public void show() {}
}