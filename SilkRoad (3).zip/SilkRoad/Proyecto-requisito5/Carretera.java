import java.util.ArrayList;

/**
 * Clase que representa una carretera básica con tiendas y robots
 */
public class Carretera {
    // Lista de tiendas en la carretera
    private ArrayList<Tienda> stores;
    // Lista de robots en la carretera
    private ArrayList<Robot> robots;
    
    /**
     * Constructor que crea una carretera de longitud específica
     * @param length Longitud de la carretera
     */
    public Carretera(int length) {}
    
    /**
     * Obtiene la longitud actual de la carretera
     * @return Longitud en metros
     */
    public int length() {}
    
    /**
     * Añade una tienda a la carretera
     * @param inters Tienda a añadir
     * @return true si se añadió exitosamente, false otherwise
     */
    public boolean addStore(Tienda inters) {}
    
    /**
     * Añade un robot a la carretera
     * @param trobot Robot a añadir
     * @return true si se añadió exitosamente, false otherwise
     */
    public boolean addRobot(Robot trobot) {}
    
    /**
     * Proporciona información sobre una ubicación específica
     * @param location Ubicación a consultar
     */
    public void infoLocation(int location) {}
}

