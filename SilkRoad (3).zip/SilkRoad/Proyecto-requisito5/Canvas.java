import java.util.ArrayList;

/**
 * Clase principal Canvas que gestiona todo el sistema:
 * - Tiendas (agregar, eliminar, reabastecer)
 * - Robots (agregar, eliminar, retornar a posición inicial) 
 * - SilkRoad (rutas de seda con longitud específica)
 */
public class Canvas {
    // Listas para almacenar todos los elementos del sistema
    private ArrayList<Tienda> tiendas;
    private ArrayList<Robot> robots;
    private ArrayList<SilkRoad> rutasSeda;
      // NUEVOS ATRIBUTOS PARA GANANCIAS GLOBALES
    private double gananciasGlobales;    //Ganancias totales de todas las tiendas
    private double costosGlobales;       //Costos totales de reabastecimiento
    
    
    /**
     * Constructor principal - Inicializa todas las listas
     */
    public Canvas() {
        tiendas = new ArrayList<Tienda>();
        robots = new ArrayList<Robot>();
        rutasSeda = new ArrayList<SilkRoad>();
        System.out.println("Sistema Canvas inicializado con gestión de Tiendas, Robots y Rutas de Seda.");
         // INICIALIZAR CONTADORES DE GANANCIAS
        gananciasGlobales = 0.0;
        costosGlobales = 0.0;
        
        System.out.println("Sistema Canvas inicializado con módulo de ganancias.");
    }
    
    /**
    }
    
    // ========== MÉTODOS DE GESTIÓN DE TIENDAS ==========
    
    /**
     * MÉTODO 1: Agregar una nueva tienda al sistema
     * @param nombre - Nombre de la tienda
     * @param x - Posición X
     * @param y - Posición Y
     */
    public void agregarTienda(String nombre, int x, int y) {
        //Verificar si ya existe una tienda con ese nombre
        for (Tienda tienda : tiendas) {
            if (tienda.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Ya existe una tienda con el nombre '" + nombre + "'.");
                return;
            }
        }
        
        Tienda nuevaTienda = new Tienda(x, y, 40, 30, nombre);
        tiendas.add(nuevaTienda);
        System.out.println("Tienda '" + nombre + "' agregada exitosamente.");
        mostrarEstadoTiendas();
    }
    
    /**
     * MÉTODO 2: Eliminar una tienda por nombre
     * @param nombre - Nombre de la tienda a eliminar
     */
    public void eliminarTienda(String nombre) {
        for (int i = 0; i < tiendas.size(); i++) {
            if (tiendas.get(i).getNombre().equalsIgnoreCase(nombre)) {
                Tienda eliminada = tiendas.remove(i);
                System.out.println("Tienda '" + eliminada.getNombre() + "' eliminada.");
                mostrarEstadoTiendas();
                return;
            }
        }
        System.out.println("No se encontró la tienda '" + nombre + "'.");
    }
    
    /**
     * MÉTODO 3: Reabastecer todas las tiendas del sistema
     */
    public void reabastecerTodasLasTiendas() {
        if (tiendas.isEmpty()) {
            System.out.println("No hay tiendas para reabastecer.");
            return;
        }
        
        System.out.println("Reabasteciendo TODAS las tiendas...");
        for (Tienda tienda : tiendas) {
            tienda.reabastecer(30);
        }
        System.out.println(tiendas.size() + " tiendas reabastecidas.");
        mostrarEstadoTiendas();
    }
    
    /**
     * MÉTODO AUXILIAR: Mostrar estado de tiendas
     */
    private void mostrarEstadoTiendas() {
        System.out.println("\n--- ESTADO DE TIENDAS ---");
        if (tiendas.isEmpty()) {
            System.out.println("No hay tiendas registradas.");
        } else {
            for (Tienda tienda : tiendas) {
                System.out.println(tienda.getNombre() + 
                                 " | Inventario: " + tienda.getInventario() +
                                 " | Posición: (" + tienda.getX() + ", " + tienda.getY() + ")");
            }
        }
        System.out.println("Total: " + tiendas.size() + " tiendas\n");
    }
    /**
     * MÉTODO 4: Agregar un nuevo robot al sistema
     * @param nombre - Nombre del robot
     * @param posX - Posición inicial X
     * @param posY - Posición inicial Y
     */
    public void agregarRobot(String nombre, int posX, int posY) {
        // Verificar si ya existe un robot con ese nombre
        for (Robot robot : robots) {
            if (robot.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Ya existe un robot con el nombre '" + nombre + "'.");
                return;
            }
        }
        
        Robot nuevoRobot = new Robot(nombre, posX, posY);
        robots.add(nuevoRobot);
        System.out.println("Robot '" + nombre + "' agregado exitosamente.");
        mostrarEstadoRobots();
    }
    
    /**
     * MÉTODO 5: Eliminar un robot por nombre
     * @param nombre - Nombre del robot a eliminar
     */
    public void eliminarRobot(String nombre) {
        for (int i = 0; i < robots.size(); i++) {
            if (robots.get(i).getNombre().equalsIgnoreCase(nombre)) {
                Robot eliminado = robots.remove(i);
                System.out.println("Robot '" + eliminado.getNombre() + "' eliminado.");
                mostrarEstadoRobots();
                return;
            }
        }
        System.out.println("No se encontró el robot '" + nombre + "'.");
    }
    
    /**
     * MÉTODO 6: Retornar TODOS los robots a sus posiciones iniciales
     */
    public void retornarRobotsAPosicionesIniciales() {
        if (robots.isEmpty()) {
            System.out.println("No hay robots en el sistema.");
            return;
        }
        
        System.out.println("Retornando TODOS los robots a sus posiciones iniciales...");
        int robotsRetornados = 0;
        
        for (Robot robot : robots) {
            if (robot.isActivo()) {
                robot.retornarAPosicionInicial();
                robotsRetornados++;
            }
        }
        
        System.out.println(robotsRetornados + " robots retornados a sus posiciones iniciales.");
        mostrarEstadoRobots();
    }
    
    /**
     * MÉTODO 7: Mover un robot a nueva posición
     * @param nombre - Nombre del robot
     * @param nuevaX - Nueva coordenada X
     * @param nuevaY - Nueva coordenada Y
     */
    public void moverRobot(String nombre, int nuevaX, int nuevaY) {
        for (Robot robot : robots) {
            if (robot.getNombre().equalsIgnoreCase(nombre)) {
                robot.mover(nuevaX, nuevaY);
                System.out.println("Robot '" + nombre + "' movido a (" + nuevaX + ", " + nuevaY + ")");
                return;
            }
        }
        System.out.println("No se encontró el robot '" + nombre + "'.");
    }
    
    /**
     * MÉTODO AUXILIAR: Mostrar estado de robots
     */
    private void mostrarEstadoRobots() {
        System.out.println("\n--- ESTADO DE ROBOTS ---");
        if (robots.isEmpty()) {
            System.out.println("No hay robots registrados.");
        } else {
            for (Robot robot : robots) {
                System.out.println(robot.getInfo());
            }
        }
        System.out.println("Total: " + robots.size() + " robots\n");
    }
    /**
     * MÉTODO 8: Crear una ruta de seda con longitud específica
     * @param nombre - Nombre de la ruta
     * @param longitudDeseada - Longitud deseada de la ruta
     * @param x - Posición X del área
     * @param y - Posición Y del área
     * @param width - Ancho del área
     * @param height - Alto del área
     */
    public void crearRutaSeda(String nombre, double longitudDeseada, int x, int y, int width, int height) {
        // Verificar si ya existe una ruta con ese nombre
        for (SilkRoad ruta : rutasSeda) {
            if (ruta.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Ya existe una ruta con el nombre '" + nombre + "'.");
                return;
            }
        }
        
        SilkRoad nuevaRuta = new SilkRoad(nombre, x, y, width, height);
        rutasSeda.add(nuevaRuta);
        nuevaRuta.crearRutaConLongitud(longitudDeseada, null);
        System.out.println("Ruta de seda '" + nombre + "' creada con longitud: " + longitudDeseada);
        mostrarEstadoRutas();
    }
    
    /**
     * MÉTODO 9: Crear ruta de seda que pase por puntos específicos
     * @param nombre - Nombre de la ruta
     * @param puntos - Array de puntos [[x1,y1], [x2,y2], ...]
     * @param longitudDeseada - Longitud deseada
     */
    public void crearRutaSedaConPuntos(String nombre, int[][] puntos, double longitudDeseada) {
        if (puntos == null || puntos.length == 0) {
            System.out.println("Se necesitan puntos para crear la ruta.");
            return;
        }
        
        SilkRoad ruta = new SilkRoad(nombre, puntos[0][0], puntos[0][1], 500, 500);
        rutasSeda.add(ruta);
        ruta.crearRutaConLongitud(longitudDeseada, puntos);
        mostrarEstadoRutas();
    }
    
    /**
     * MÉTODO 10: Crear ruta que conecte todas las tiendas existentes
     * @param nombre - Nombre de la ruta
     * @param longitudDeseada - Longitud aproximada deseada
     */
    public void crearRutaEntreTiendas(String nombre, double longitudDeseada) {
        if (tiendas.isEmpty()) {
            System.out.println("⚠️ No hay tiendas para conectar.");
            return;
        }
        
        SilkRoad ruta = new SilkRoad(nombre, 0, 0, 500, 500);
        rutasSeda.add(ruta);
        ruta.crearRutaEntreTiendas(tiendas, longitudDeseada);
        System.out.println("🔗 Ruta '" + nombre + "' creada conectando " + tiendas.size() + " tiendas.");
        mostrarEstadoRutas();
    }
    
    /**
     * MÉTODO AUXILIAR: Mostrar estado de rutas
     */
    private void mostrarEstadoRutas() {
        System.out.println("\n--- ESTADO DE RUTAS DE SEDA ---");
        if (rutasSeda.isEmpty()) {
            System.out.println("No hay rutas de seda registradas.");
        } else {
            for (SilkRoad ruta : rutasSeda) {
                System.out.println(ruta.getNombre() + 
                                 " | Longitud: " + String.format("%.2f", ruta.getLongitud()) +
                                 " | Puntos: " + ruta.getNumeroPuntos());
            }
        }
        System.out.println("Total: " + rutasSeda.size() + " rutas\n");
    }
    /**
     * MÉTODO: Obtener estadísticas generales del sistema
     */
    public void mostrarEstadisticas() {
        System.out.println("\n=== ESTADÍSTICAS DEL SISTEMA ===");
        System.out.println("Tiendas: " + tiendas.size());
        System.out.println("Robots: " + robots.size());
        System.out.println("Rutas de Seda: " + rutasSeda.size());
        
        int inventarioTotal = 0;
        for (Tienda tienda : tiendas) {
            inventarioTotal += tienda.getInventario();
        }
        System.out.println("Inventario total: " + inventarioTotal + " unidades");
    }
    
    /**
     * MÉTODO DE PRUEBA COMPLETO - Prueba todas las funcionalidades
     */
    public void probarSistemaCompleto() {
        System.out.println("=== INICIANDO PRUEBA COMPLETA DEL SISTEMA ===");
        
        // 1. PROBAR TIENDAS
        System.out.println("\n--- Probando gestión de tiendas ---");
        agregarTienda("Supermercado Central", 100, 100);
        agregarTienda("Tienda Norte", 300, 200);
        agregarTienda("MiniMarket Sur", 150, 400);
        reabastecerTodasLasTiendas();
        
        // 2. PROBAR ROBOTS
        System.out.println("\n--- Probando gestión de robots ---");
        agregarRobot("RobotGuardian", 50, 50);
        agregarRobot("RobotRepartidor", 200, 300);
        moverRobot("RobotRepartidor", 400, 400);
        retornarRobotsAPosicionesIniciales();
        
        // 3. PROBAR RUTAS DE SEDA
        System.out.println("\n--- Probando rutas de seda ---");
        crearRutaSeda("Ruta Principal", 350.0, 0, 0, 500, 500);
        
        int[][] puntosEstrategicos = {{100, 100}, {250, 300}, {400, 200}};
        crearRutaSedaConPuntos("Ruta Comercial", puntosEstrategicos, 450.0);
        
        crearRutaEntreTiendas("Ruta de Suministro", 400.0);
        
        // 4. MOSTRAR ESTADÍSTICAS FINALES
        mostrarEstadisticas();
        System.out.println("✅ Prueba del sistema completada exitosamente.");
    }
    
    /**
     * MÉTODO: Limpiar todo el sistema (reiniciar)
     */
    public void limpiarSistema() {
        tiendas.clear();
        robots.clear();
        rutasSeda.clear();
        System.out.println("Sistema limpiado. Todas las tiendas, robots y rutas eliminados.");
    }
}