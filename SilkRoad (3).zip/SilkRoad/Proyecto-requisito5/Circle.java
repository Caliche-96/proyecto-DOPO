/**
 * Clase que representa una forma circular
 */
public class Circle {
    // Implementación del círculo
}

