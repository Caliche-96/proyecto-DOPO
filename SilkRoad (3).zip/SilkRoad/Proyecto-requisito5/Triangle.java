/**
 * Clase que representa una forma triangular
 */
public class Triangle {
    // Implementación del triángulo
}
