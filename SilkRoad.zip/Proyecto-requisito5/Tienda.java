/**
 * Clase Tienda con sistema de ventas y ganancias
 */
public class Tienda extends Rectangle {
    private String nombre;
    private int inventario;
    private static int contadorTiendas = 0;
    private int id;
    
    // NUEVOS ATRIBUTOS PARA GANANCIAS
    private double gananciasTotales;      // Ganancias acumuladas
    private int ventasTotales;           // Número total de ventas
    private double precioProducto;       // Precio por unidad
    private double costoProducto;        // Costo por unidad
    
    public Tienda(int x, int y, int width, int height, String nombre) {
        super(x, y, width, height);
        this.nombre = nombre;
        this.inventario = 50; // Inventario inicial
        
        // INICIALIZAR SISTEMA DE GANANCIAS
        this.gananciasTotales = 0.0;
        this.ventasTotales = 0;
        this.precioProducto = 10.0;  // Precio de venta por defecto
        this.costoProducto = 6.0;    // Costo por unidad por defecto
        
        this.id = ++contadorTiendas;
    }
    
    /**
     * MÉTODO MEJORADO: Vender productos y calcular ganancias
     * @param cantidad - Cantidad a vender
     * @return true si la venta fue exitosa, false si no hay inventario
     */
    public boolean vender(int cantidad) {
        if (inventario >= cantidad) {
            inventario -= cantidad;
            
            // CALCULAR GANANCIAS DE ESTA VENTA
            double gananciaVenta = (precioProducto - costoProducto) * cantidad;
            gananciasTotales += gananciaVenta;
            ventasTotales += cantidad;
            
            System.out.println("💰 Venta exitosa en '" + nombre + "': " + cantidad + 
                             " unidades | Ganancia: $" + gananciaVenta);
            return true;
        }
        System.out.println("❌ Venta fallida en '" + nombre + "': Inventario insuficiente");
        return false;
    }
    
    /**
     * MÉTODO: Vender una cantidad aleatoria (para simulaciones)
     * @return Cantidad vendida (0 si no hay inventario)
     */
    public int venderAleatorio() {
        if (inventario == 0) return 0;
        
        int cantidad = (int)(Math.random() * Math.min(10, inventario)) + 1;
        if (vender(cantidad)) {
            return cantidad;
        }
        return 0;
    }
    
    /**
     * MÉTODO: Reabastecer (ahora también considera el costo)
     * @param cantidad - Cantidad a reabastecer
     */
    public void reabastecer(int cantidad) {
        double costoReabastecimiento = costoProducto * cantidad;
        inventario += cantidad;
        
        System.out.println("📦 Tienda '" + nombre + "' reabastecida: +" + cantidad + 
                         " unidades | Costo: $" + costoReabastecimiento);
    }
    
    // ========== MÉTODOS DE CONSULTA DE GANANCIAS ==========
    
    /**
     * @return Ganancias totales acumuladas
     */
    public double getGananciasTotales() {
        return gananciasTotales;
    }
    
    /**
     * @return Número total de ventas realizadas
     */
    public int getVentasTotales() {
        return ventasTotales;
    }
    
    /**
     * @return Ganancia por unidad (precio - costo)
     */
    public double getGananciaPorUnidad() {
        return precioProducto - costoProducto;
    }
    
    /**
     * @return Precio actual del producto
     */
    public double getPrecioProducto() {
        return precioProducto;
    }
    
    /**
     * @return Costo actual del producto
     */
    public double getCostoProducto() {
        return costoProducto;
    }
    
    /**
     * MÉTODO: Configurar precios y costos
     * @param precio - Nuevo precio de venta
     * @param costo - Nuevo costo de compra
     */
    public void configurarPrecios(double precio, double costo) {
        this.precioProducto = precio;
        this.costoProducto = costo;
        System.out.println("📊 Tienda '" + nombre + "' - Precio: $" + precio + " | Costo: $" + costo);
    }
    
    /**
     * MÉTODO: Obtener reporte detallado de ganancias
     * @return String con el reporte completo
     */
    public String getReporteGanancias() {
        return "🏪 " + nombre + 
               " | Ventas: " + ventasTotales +
               " | Inventario: " + inventario +
               " | Ganancias: $" + String.format("%.2f", gananciasTotales) +
               " | Margen: $" + String.format("%.2f", getGananciaPorUnidad()) + "/unidad";
    }
    
    /**
     * MÉTODO: Reiniciar estadísticas de ganancias (mantiene inventario)
     */
    public void reiniciarGanancias() {
        gananciasTotales = 0.0;
        ventasTotales = 0;
        System.out.println("🔄 Estadísticas de ganancias reiniciadas en '" + nombre + "'");
    }
    
    // ... (los demás métodos se mantienen igual)
    public String getNombre() { return nombre; }
    public int getInventario() { return inventario; }
    public int getId() { return id; }
}