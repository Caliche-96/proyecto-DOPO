/**
 * Clase base que representa un rectángulo en el canvas
 * Proporciona posición y dimensiones básicas
 * Clase padre de Tienda, SilkRoad, BarraStatus y Carretera
 */
public class Rectangle {
    // Atributos de posición y tamaño
    private int x, y;        // Coordenadas (esquina superior izquierda)
    private int width, height; // Dimensiones del rectángulo
    
    /**
     * Constructor de Rectangle
     * @param x - Posición X
     * @param y - Posición Y  
     * @param width - Ancho del rectángulo
     * @param height - Alto del rectángulo
     */
    public Rectangle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    // ========== MÉTODOS GETTER (acceso a atributos privados) ==========
    
    /**
     * @return Posición X del rectángulo
     */
    public int getX() { return x; }
    
    /**
     * @return Posición Y del rectángulo  
     */
    public int getY() { return y; }
    
    /**
     * @return Ancho del rectángulo
     */
    public int getWidth() { return width; }
    
    /**
     * @return Alto del rectángulo
     */
    public int getHeight() { return height; }
}