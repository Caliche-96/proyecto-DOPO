import java.util.ArrayList;

/**
 * Clase que representa una Ruta de Seda (SilkRoad)
 * Hereda de Rectangle para tener posición y dimensiones
 * Gestiona puntos de la ruta, longitud y conexiones entre tiendas
 */
public class SilkRoad extends Rectangle {
    private String nombre;
    private ArrayList<Punto> puntosRuta;  // Lista de puntos que forman la ruta
    private double longitud;              // Longitud total de la ruta
    private boolean activa;               // Estado de la ruta
    
    /**
     * Clase interna para representar puntos en la ruta
     */
    private class Punto {
        int x, y;
        
        public Punto(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
        // Calcular distancia entre dos puntos
        public double distanciaA(Punto otro) {
            int deltaX = this.x - otro.x;
            int deltaY = this.y - otro.y;
            return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        }
        
        @Override
        public String toString() {
            return "(" + x + ", " + y + ")";
        }
    }
    
    /**
     * Constructor básico - Crea una ruta vacía
     * @param nombre - Nombre de la ruta
     * @param x - Posición X inicial
     * @param y - Posición Y inicial
     * @param width - Ancho del área de la ruta
     * @param height - Alto del área de la ruta
     */
    public SilkRoad(String nombre, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.nombre = nombre;
        this.puntosRuta = new ArrayList<Punto>();
        this.longitud = 0.0;
        this.activa = true;
    }
    
    /**
     * MÉTODO PRINCIPAL: Crear una ruta de seda con una longitud específica
     * Genera puntos automáticamente para alcanzar la longitud deseada
     * @param longitudDeseada - Longitud total que debe tener la ruta
     * @param puntosFijos - Puntos específicos por donde debe pasar la ruta (opcional)
     */
    public void crearRutaConLongitud(double longitudDeseada, int[][] puntosFijos) {
        System.out.println("🛣️ Creando ruta de seda '" + nombre + "' con longitud: " + longitudDeseada);
        
        // Limpiar ruta existente
        puntosRuta.clear();
        longitud = 0.0;
        
        // Agregar puntos fijos si se proporcionan
        if (puntosFijos != null && puntosFijos.length > 0) {
            for (int[] punto : puntosFijos) {
                if (punto.length == 2) {
                    agregarPunto(punto[0], punto[1]);
                }
            }
        }
        
        // Si no hay puntos fijos, empezar desde la posición de la ruta
        if (puntosRuta.isEmpty()) {
            agregarPunto(getX(), getY());
        }
        
        // Generar puntos adicionales hasta alcanzar la longitud deseada
        generarPuntosParaLongitud(longitudDeseada);
        
        System.out.println("✅ Ruta creada exitosamente. Longitud final: " + String.format("%.2f", longitud));
        mostrarInfoRuta();
    }
    
    /**
     * MÉTODO: Generar puntos automáticamente para alcanzar la longitud deseada
     * @param longitudDeseada - Longitud objetivo
     */
    private void generarPuntosParaLongitud(double longitudDeseada) {
        Punto ultimoPunto = puntosRuta.get(puntosRuta.size() - 1);
        
        while (longitud < longitudDeseada) {
            // Generar nuevo punto en dirección aleatoria pero controlada
            int nuevoX = ultimoPunto.x + (int)(Math.random() * 100) - 50; // -50 a +50
            int nuevoY = ultimoPunto.y + (int)(Math.random() * 100) - 50;
            
            // Asegurar que el punto esté dentro del área de la ruta
            nuevoX = Math.max(getX(), Math.min(getX() + getWidth(), nuevoX));
            nuevoY = Math.max(getY(), Math.min(getY() + getHeight(), nuevoY));
            
            Punto nuevoPunto = new Punto(nuevoX, nuevoY);
            double segmentoLongitud = ultimoPunto.distanciaA(nuevoPunto);
            
            // Solo agregar si no excede demasiado la longitud deseada
            if (longitud + segmentoLongitud <= longitudDeseada * 1.1) {
                agregarPunto(nuevoPunto);
                ultimoPunto = nuevoPunto;
            } else {
                break; // Evitar bucles infinitos
            }
        }
        
        // Ajuste final para acercarse lo más posible a la longitud deseada
        ajustarLongitudFinal(longitudDeseada);
    }
    
    /**
     * MÉTODO: Ajustar el último segmento para acercarse a la longitud exacta
     * @param longitudDeseada - Longitud objetivo
     */
    private void ajustarLongitudFinal(double longitudDeseada) {
        if (puntosRuta.size() < 2 || longitud >= longitudDeseada) return;
        
        Punto penultimo = puntosRuta.get(puntosRuta.size() - 2);
        Punto ultimo = puntosRuta.get(puntosRuta.size() - 1);
        
        // Calcular dirección y distancia necesaria
        double distanciaNecesaria = longitudDeseada - longitud;
        double dx = ultimo.x - penultimo.x;
        double dy = ultimo.y - penultimo.y;
        double distanciaActual = Math.sqrt(dx * dx + dy * dy);
        
        if (distanciaActual > 0) {
            double factor = (distanciaActual + distanciaNecesaria) / distanciaActual;
            int nuevoX = (int)(penultimo.x + dx * factor);
            int nuevoY = (int)(penultimo.y + dy * factor);
            
            // Reemplazar último punto
            puntosRuta.remove(puntosRuta.size() - 1);
            agregarPunto(nuevoX, nuevoY);
        }
    }
    
    /**
     * MÉTODO: Agregar un punto a la ruta
     * @param x - Coordenada X del punto
     * @param y - Coordenada Y del punto
     */
    public void agregarPunto(int x, int y) {
        Punto nuevoPunto = new Punto(x, y);
        agregarPunto(nuevoPunto);
    }
    
    /**
     * MÉTODO: Agregar un punto a la ruta (sobrecarga)
     * @param punto - Punto a agregar
     */
    private void agregarPunto(Punto punto) {
        if (!puntosRuta.isEmpty()) {
            Punto ultimoPunto = puntosRuta.get(puntosRuta.size() - 1);
            longitud += ultimoPunto.distanciaA(punto);
        }
        puntosRuta.add(punto);
    }
    
    /**
     * MÉTODO: Crear ruta recta entre dos puntos con longitud específica
     * @param inicioX - X inicial
     * @param inicioY - Y inicial
     * @param longitudDeseada - Longitud de la ruta recta
     * @param anguloGrados - Ángulo en grados (0 = derecha, 90 = arriba, etc.)
     */
    public void crearRutaRecta(int inicioX, int inicioY, double longitudDeseada, double anguloGrados) {
        puntosRuta.clear();
        longitud = 0.0;
        
        // Convertir ángulo a radianes
        double anguloRadianes = Math.toRadians(anguloGrados);
        
        // Calcular punto final
        int finX = inicioX + (int)(longitudDeseada * Math.cos(anguloRadianes));
        int finY = inicioY + (int)(longitudDeseada * Math.sin(anguloRadianes));
        
        agregarPunto(inicioX, inicioY);
        agregarPunto(finX, finY);
        
        System.out.println("📏 Ruta recta creada: " + longitudDeseada + " unidades, ángulo: " + anguloGrados + "°");
        mostrarInfoRuta();
    }
    
    /**
     * MÉTODO: Conectar tiendas con una ruta que pase por todas ellas
     * @param tiendas - Array de tiendas a conectar
     * @param longitudDeseada - Longitud aproximada deseada
     */
    public void crearRutaEntreTiendas(ArrayList<Tienda> tiendas, double longitudDeseada) {
        System.out.println("🔗 Creando ruta que conecta " + tiendas.size() + " tiendas");
        
        puntosRuta.clear();
        longitud = 0.0;
        
        if (tiendas.isEmpty()) return;
        
        // Agregar primera tienda
        Tienda primera = tiendas.get(0);
        agregarPunto(primera.getX() + primera.getWidth()/2, primera.getY() + primera.getHeight()/2);
        
        // Conectar tiendas en orden
        for (int i = 1; i < tiendas.size(); i++) {
            Tienda tienda = tiendas.get(i);
            agregarPunto(tienda.getX() + tienda.getWidth()/2, tienda.getY() + tienda.getHeight()/2);
        }
        
        // Ajustar para alcanzar longitud deseada
        if (longitud < longitudDeseada) {
            extenderRuta(longitudDeseada);
        }
        
        System.out.println("✅ Ruta entre tiendas creada. Longitud: " + String.format("%.2f", longitud));
        mostrarInfoRuta();
    }
    
    /**
     * MÉTODO: Extender la ruta existente para alcanzar longitud deseada
     * @param longitudDeseada - Longitud objetivo
     */
    private void extenderRuta(double longitudDeseada) {
        if (puntosRuta.size() < 2) return;
        
        Punto ultimo = puntosRuta.get(puntosRuta.size() - 1);
        Punto direccion = new Punto(
            ultimo.x - puntosRuta.get(puntosRuta.size() - 2).x,
            ultimo.y - puntosRuta.get(puntosRuta.size() - 2).y
        );
        
        double distanciaNecesaria = longitudDeseada - longitud;
        double distanciaActual = Math.sqrt(direccion.x * direccion.x + direccion.y * direccion.y);
        
        if (distanciaActual > 0) {
            double factor = distanciaNecesaria / distanciaActual;
            int nuevoX = ultimo.x + (int)(direccion.x * factor);
            int nuevoY = ultimo.y + (int)(direccion.y * factor);
            agregarPunto(nuevoX, nuevoY);
        }
    }
    
    // ========== MÉTODOS DE CONSULTA ==========
    
    /**
     * @return Longitud actual de la ruta
     */
    public double getLongitud() { return longitud; }
    
    /**
     * @return Nombre de la ruta
     */
    public String getNombre() { return nombre; }
    
    /**
     * @return Número de puntos en la ruta
     */
    public int getNumeroPuntos() { return puntosRuta.size(); }
    
    /**
     * @return true si la ruta está activa
     */
    public boolean isActiva() { return activa; }
    
    /**
     * MÉTODO: Mostrar información detallada de la ruta
     */
    public void mostrarInfoRuta() {
        System.out.println("\n--- INFORMACIÓN DE RUTA ---");
        System.out.println("Nombre: " + nombre);
        System.out.println("Longitud: " + String.format("%.2f", longitud));
        System.out.println("Puntos: " + puntosRuta.size());
        System.out.println("Activa: " + activa);
        System.out.println("Área: (" + getX() + ", " + getY() + ") [" + getWidth() + "x" + getHeight() + "]");
        
        if (!puntosRuta.isEmpty()) {
            System.out.println("Primer punto: " + puntosRuta.get(0));
            System.out.println("Último punto: " + puntosRuta.get(puntosRuta.size() - 1));
        }
        System.out.println("----------------------------\n");
    }
    
    /**
     * MÉTODO: Obtener puntos como array 2D para visualización
     * @return Array de puntos [x, y]
     */
    public int[][] getPuntos() {
        int[][] puntosArray = new int[puntosRuta.size()][2];
        for (int i = 0; i < puntosRuta.size(); i++) {
            puntosArray[i][0] = puntosRuta.get(i).x;
            puntosArray[i][1] = puntosRuta.get(i).y;
        }
        return puntosArray;
    }
}