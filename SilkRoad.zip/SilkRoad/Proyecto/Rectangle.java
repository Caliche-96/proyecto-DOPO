/**
 * Clase que representa una forma rectangular
 */
public class Rectangle {
    // Implementación del rectángulo
}

