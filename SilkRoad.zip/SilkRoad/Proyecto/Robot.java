/**
 * Clase que representa un robot en el sistema
 * Gestiona movimiento y ubicación
 */
public class Robot {
    //Froma de cada robot
    private Triangle forma;
    //Obtencion de monedas de los robots en las tiendas
    private Tiendas tenges;
    // Ubicación actual real del robot
    private int actualLocation;
    // Ubicación objetivo o asignada del robot
    private int location;
    // Identificador único del robot
    private int id;
    
    /**
     * Constructor que crea un robot en una ubicación específica
     * @param location Ubicación inicial del robot
     */
    public Robot(int location) {
    
    }
    
    /**
     * Mueve el robot hacia una tienda específica
     * @param store Tienda destino del movimiento
     * @return Tiempo o código de resultado del movimiento
     */
    public int moveTo(Tiendas tenges)
    {
        tenges= Tiendas.get();
        id=tenges ; //por decir algo
        return id;
    }
    
    /**
     * Calcula la distancia hasta una tienda específica
     * @param store Tienda para calcular la distancia
     * @return Distancia en metros hasta la tienda
     */
    public int DistanceTo(Tiendas store) {
    
    }
}